// Signup Form Validation and Submission
document.querySelector("#signup-form").addEventListener("submit", async function (event) {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(event.target); // Collect form data
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    // Basic validation
    if (!formData.get("username") || !formData.get("email") || !formData.get("password") || !confirmPassword) {
        alert("Please fill out all fields.");
        return;
    }

    // Email validation
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(formData.get("email"))) {
        alert("Please enter a valid email address.");
        return;
    }

    // Password length validation
    if (formData.get("password").length < 8) {
        alert("Password must be at least 8 characters long.");
        return;
    }

    // Password match validation
    if (formData.get("password") !== confirmPassword) {
        alert("Passwords do not match.");
        return;
    }

    // Submit form data via fetch
    try {
        const response = await fetch(event.target.action, {
            method: "POST",
            body: formData,
        });

        const result = await response.json(); // Parse the JSON response

        // Message container for displaying feedback
        const messageContainer = document.getElementById("message-container");
        if (result.status === "success") {
            messageContainer.innerHTML = `<p class="success">${result.message}</p>`;
            setTimeout(() => {
                window.location.href = "/login"; // Redirect to login
            }, 2000);
        } else {
            messageContainer.innerHTML = `<p class="error">${result.message}</p>`;
        }
    } catch (error) {
        console.error("Error during form submission:", error);
        const messageContainer = document.getElementById("message-container");
        messageContainer.innerHTML = `<p class="error">An unexpected error occurred. Please try again later.</p>`;
    }
});

// Redirect Utility Function
function redirectToLogin() {
    window.location.href = "/login"; // Redirect to login page
}

// Generic Form Submission Handler
document.querySelector("form").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent default submission
    redirectToLogin(); // Redirect after handling submission
});

// Update Form Handler
document.querySelector("#update-form").addEventListener("submit", async function (event) {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(event.target); // Collect form data

    try {
        const response = await fetch(event.target.action, {
            method: "POST",
            body: formData,
        });

        const result = await response.json();

        // Display feedback
        const messageContainer = document.getElementById("message-container");
        if (result.status === "success") {
            messageContainer.innerHTML = `<p class="success">${result.message}</p>`;
        } else {
            messageContainer.innerHTML = `<p class="error">${result.message}</p>`;
        }
    } catch (error) {
        console.error("Error:", error);
        alert("An unexpected error occurred.");
    }
});



// Delete User Handler
document.querySelectorAll(".delete-button").forEach(button => {
    button.addEventListener("click", async function () {
        const userId = this.dataset.userId; // Get the user ID from data attribute

        if (confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
            try {
                const response = await fetch(`/delete_user/${userId}`, {
                    method: "POST",
                });

                const result = await response.json();

                // Display feedback
                const messageContainer = document.getElementById("message-container");
                if (result.status === "success") {
                    messageContainer.innerHTML = `<p class="success">${result.message}</p>`;
                    this.closest("tr").remove(); // Remove the user row from the table
                } else {
                    messageContainer.innerHTML = `<p class="error">${result.message}</p>`;
                }
            } catch (error) {
                console.error("Error:", error);
                alert("An unexpected error occurred.");
            }
        }
    });
});

// Handle Update Form Submission
document.querySelector("#account-form").addEventListener("submit", async function (event) {
    event.preventDefault(); // Prevent default form submission

    const formData = new FormData(event.target);

    try {
        const response = await fetch(event.target.action, {
            method: "POST",
            body: formData,
        });

        const result = await response.json();

        const messageContainer = document.getElementById("message-container");
        if (result.status === "success") {
            messageContainer.innerHTML = `<p class="text-success">${result.message}</p>`;
        } else {
            messageContainer.innerHTML = `<p class="text-danger">${result.message}</p>`;
        }
    } catch (error) {
        console.error("Error updating account:", error);
        const messageContainer = document.getElementById("message-container");
        messageContainer.innerHTML = `<p class="text-danger">An unexpected error occurred.</p>`;
    }
});

// Handle Delete Account Button
document.querySelector("#delete-account-button").addEventListener("click", async function () {
    const userId = this.dataset.userId; // Fetch user ID from the button

    // Confirm deletion
    if (!confirm("Are you sure you want to delete your account? This action is irreversible.")) {
        return;
    }

    try {
        // Send DELETE request
        const response = await fetch(`/delete_user/${userId}`, {
            method: "POST",
        });

        const result = await response.json();
        const messageContainer = document.getElementById("message-container");

        if (result.status === "success") {
            messageContainer.innerHTML = `<p class="success">${result.message}</p>`;
            setTimeout(() => {
                window.location.href = "/login"; // Redirect to login after deletion
            }, 2000);
        } else {
            messageContainer.innerHTML = `<p class="error">${result.message}</p>`;
        }
    } catch (error) {
        console.error("Error during deletion:", error);
        alert("An error occurred. Please try again.");
    }
});

function togglePasswordVisibility(fieldId, button) {
    const field = document.getElementById(fieldId);
    const isPasswordVisible = field.type === 'text';
    field.type = isPasswordVisible ? 'password' : 'text';
    button.innerHTML = isPasswordVisible
        ? '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">\n                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />\n                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 9.542 7-.276.833-.842 1.542-1.542 2-.7.458-1.476.832-2.316 1.088M2.458 12a9.975 9.975 0 011.342-2.042M2.458 12a9.975 9.975 0 001.342 2.042M21.542 12a9.975 9.975 0 01-1.342 2.042M21.542 12a9.975 9.975 0 00-1.342-2.042" />\n                    </svg>'
        : '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">\n                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.98 8.548a10.477 10.477 0 011.684-1.744m4.402-2.573A8.94 8.94 0 0112 4c3.019 0 5.73 1.635 7.227 4.035M12 16c-1.121 0-2.08-.364-2.9-.971M12 16c3.019 0 5.73-1.635 7.227-4.035M12 16a10.477 10.477 0 003.93-1.664M12 8c1.333 0 2.552.667 3.373 1.65M12 8a4.5 4.5 0 00-4.5 4.5c0 .427.048.84.136 1.236M4.73 19.82a10.454 10.454 0 01-1.54-2.78m14.755 2.543a8.933 8.933 0 001.245-1.731m-.558-7.051a8.933 8.933 0 00-1.686-2.127" />\n                    </svg>';
}

document.getElementById("mock-google-login").addEventListener("submit", (e) => {
    e.preventDefault(); // Prevent the form from refreshing the page

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (!email || !password) {
        alert("Please fill out both fields.");
        return;
    }

    // Simulate sending data to the server
    alert(`Login successful for: ${email}`);
    window.location.href = "/dashboard"; // Redirect to a "dashboard" or another page
});
