// Ensure DOM is fully loaded
document.addEventListener("DOMContentLoaded", function () {
    console.log("JavaScript Loaded");

    // Signup Form Validation and Submission
    const signupForm = document.querySelector("#signup-form");
    if (signupForm) {
        signupForm.addEventListener("submit", async function (event) {
            event.preventDefault(); // Prevent default form submission

            const formData = new FormData(event.target);
            const confirmPassword = document.getElementById("confirmPassword")?.value.trim();

            // Basic validation
            if (!formData.get("username") || !formData.get("email") || !formData.get("password") || !confirmPassword) {
                alert("Please fill out all fields.");
                return;
            }

            // Email validation
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (!emailPattern.test(formData.get("email"))) {
                alert("Please enter a valid email address.");
                return;
            }

            // Password length validation
            if (formData.get("password").length < 8) {
                alert("Password must be at least 8 characters long.");
                return;
            }

            // Password match validation
            if (formData.get("password") !== confirmPassword) {
                alert("Passwords do not match.");
                return;
            }

            // Submit form data via fetch
            try {
                const response = await fetch(event.target.action, {
                    method: "POST",
                    body: formData,
                });

                const result = await response.json();

                const messageContainer = document.getElementById("message-container");
                if (result.status === "success") {
                    messageContainer.innerHTML = `<p class="success">${result.message}</p>`;
                    setTimeout(() => {
                        window.location.replace("/login"); // Redirect to login
                    }, 2000);
                } else {
                    messageContainer.innerHTML = `<p class="error">${result.message}</p>`;
                }
            } catch (error) {
                console.error("Error during form submission:", error);
                document.getElementById("message-container").innerHTML = `<p class="error">An unexpected error occurred.</p>`;
            }
        });
    }

    // Ensure correct redirection after login
    document.querySelector("form[action='/login']")?.addEventListener("submit", function () {
        setTimeout(() => {
            window.location.replace("/home"); // Redirect after successful login
        }, 500);
    });

    // Fix home page redirection logic
    if (window.location.pathname.includes("home") || window.location.pathname === "/") {
        const params = new URLSearchParams(window.location.search);
        const name = params.get("name");
        const email = params.get("email");
        const img = params.get("img");

        if (name && email && img) {
            const profilePic = document.getElementById("profile-pic");
            const accountName = document.getElementById("account-name");
            const accountEmail = document.getElementById("account-email");

            if (profilePic) profilePic.src = img;
            if (accountName) accountName.textContent = `Welcome, ${name}`;
            if (accountEmail) accountEmail.textContent = email;
        } else {
            document.body.innerHTML = "<h2>No account details found. Please log in again.</h2>";
        }
    }
});