from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import shelve
from datetime import datetime, timedelta, timezone
from werkzeug.security import generate_password_hash, check_password_hash
from create_user_db import db, User
import secrets  # For generating secure random passwords

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SECRET_KEY'] = 'FairpriceEco'
db.init_app(app)

# Google Client ID (Replace with actual one from Google Cloud Console)
GOOGLE_CLIENT_ID = "YOUR_GOOGLE_CLIENT_ID"


@app.before_request
def clear_session():
    """Expire session after inactivity or force logout on restart."""
    if 'user' in session and 'last_active' in session:
        last_active = session['last_active']
        if isinstance(last_active, str):
            last_active = datetime.fromisoformat(last_active)  # Convert string to datetime

        # Force session expiry after 30 min
        if datetime.now(timezone.utc) - last_active > timedelta(minutes=30):
            session.clear()

    # 🔹 For testing: Force logout when the server restarts
    session.pop('user', None)

    session['last_active'] = datetime.now(timezone.utc).isoformat()


# Create database tables
with app.app_context():
    db.create_all()


@app.route('/')
def index():
    """Redirect to login page if user is not logged in."""
    if 'user' not in session:
        return redirect(url_for('login'))  # 🔒 Redirect to login
    return redirect(url_for('home'))  # If logged in, go to home page


@app.route('/home')
def home():
    """Renders the base page if logged in, else redirects to login."""
    if 'user' not in session:
        return redirect(url_for('login'))

    user = User.query.filter_by(email=session['user']).first()
    if not user:
        session.clear()
        return redirect(url_for('login'))

    return render_template('base.html', user=user)


@app.route('/google-client-id')
def get_google_client_id():
    return jsonify({'client_id': GOOGLE_CLIENT_ID})


@app.route("/google-login")
def google_login():
    return render_template("google-login.html")  # Ensure this template exists


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email).first()
        print("User found:", user)  # 🔍 Debugging

        if user and check_password_hash(user.password, password):
            session.permanent = True  # Ensure session persists
            session['user'] = user.email
            print("Session set:", session['user'])  # 🔍 Debugging
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="Invalid credentials")

    return render_template('login.html')


@app.route('/logout')
def logout():
    """Clears session and redirects to login."""
    session.clear()
    return redirect(url_for('login'))


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == "POST":
        username = request.form.get("username", "")
        email = request.form.get("email", "")
        password = request.form.get("password", "")

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return render_template("signup.html", error="Email already registered!")

        try:
            hashed_password = generate_password_hash(password) if password else ""
            new_user = User(username=username, email=email, password=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error creating user: {e}")
            return render_template("signup.html", error="An error occurred. Please try again.")

    return render_template("signup.html")


@app.route('/auth/google/callback', methods=['POST'])
def google_callback():
    """Handles Google OAuth authentication and user registration if necessary."""
    email = request.form.get('email')

    if not email:
        return jsonify({"status": "error", "message": "Email is required!"})

    user = User.query.filter_by(email=email).first()
    if not user:
        try:
            random_password = secrets.token_urlsafe(16)  # Generate secure password
            hashed_password = generate_password_hash(random_password)

            new_user = User(username=email.split('@')[0], email=email, password=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            session['user'] = new_user.email
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error in Google signup: {e}")
            return jsonify({"status": "error", "message": "An error occurred. Please try again."})

    session['user'] = user.email
    return redirect(url_for('home'))


# Mock user data
user_data = {"username": "johnny", "points": 5600}


@app.route('/', methods=['GET', 'POST'])
def rewards():
    filter_option = request.args.get('filter', 'default')  # Get filter option from query params

    # Open vouchers and wallet shelve databases
    with shelve.open('vouchers.db') as vouchers_db, shelve.open('wallet.db', writeback=True) as wallet_db:
        # Load vouchers
        vouchers = {key: {**value, "points_needed": int(value["points_needed"])} for key, value in vouchers_db.items()}

        # Initialize wallet if it doesn't exist
        if user_data['username'] not in wallet_db:
            wallet_db[user_data['username']] = {"points": user_data['points'], "vouchers": [], "transactions": []}

        # Load user wallet
        wallet = wallet_db[user_data['username']]

    # Apply filters
    if filter_option == 'lowest_to_highest':
        vouchers = dict(sorted(vouchers.items(), key=lambda item: item[1]['points_needed']))
    elif filter_option == 'highest_to_lowest':
        vouchers = dict(sorted(vouchers.items(), key=lambda item: item[1]['points_needed'], reverse=True))
    elif filter_option == 'sufficient_points':
        vouchers = {key: value for key, value in vouchers.items() if wallet['points'] >= value['points_needed']}

    return render_template('rewards.html', vouchers=vouchers, wallet=wallet, filter_option=filter_option)


@app.route('/redeem/<voucher_name>', methods=['POST'])
def redeem(voucher_id):
    with shelve.open('vouchers.db') as vouchers_db, shelve.open('wallet.db', writeback=True) as wallet_db:
        voucher = vouchers_db.get(voucher_id)
        if not voucher:
            return jsonify({"status": "error", "message": "Voucher not found"})

        # Load user wallet
        wallet = wallet_db[user_data['username']]

        # Check if points are sufficient
        if wallet['points'] < voucher['points_needed']:
            return jsonify({"status": "error", "message": "Not enough points to redeem this voucher"})

        # Check if voucher is already redeemed
        if any(v['name'] == voucher['name'] for v in wallet['vouchers']):
            return jsonify({"status": "error", "message": "Voucher already redeemed"})

        # Deduct points and add the voucher to the wallet
        wallet['points'] -= voucher['points_needed']
        voucher["redeemed_date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        voucher["expiry_date"] = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")  # Expiry date is 30 days from now
        wallet['vouchers'].append(voucher)

        # Add a transaction record
        wallet['transactions'].append({
            "type": "redeemed",
            "voucher": voucher["name"],
            "points": voucher["points_needed"],
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })

        wallet_db[user_data['username']] = wallet

    return jsonify({"status": "success", "message": f"Voucher '{voucher['name']}' redeemed successfully", "remaining_points": wallet['points']})


@app.route('/wallet')
def wallet():
    with shelve.open('wallet.db') as wallet_db:
        # Ensure wallet exists for the user
        wallet = wallet_db.get(user_data['username'], {"vouchers": [], "transactions": []})
        current_vouchers = wallet.get("vouchers", [])
        past_transactions = wallet.get("transactions", [])
    return render_template('wallet.html', current_vouchers=current_vouchers, past_transactions=past_transactions)


@app.route('/events')
def events():
    return render_template('events.html')


if __name__ == '__main__':
    with shelve.open('vouchers.db', writeback=True) as db:
        if not db:
            db["1"] = {"name": "$2 FairPrice ECO Voucher", "points_needed": 1000, "description": "$2 voucher for eco-friendly items."}
            db["2"] = {"name": "$5 FairPrice ECO Voucher", "points_needed": 2600, "description": "$5 voucher for eco-friendly items."}
            db["3"] = {"name": "$10 FairPrice ECO Voucher", "points_needed": 5100, "description": "$10 voucher for eco-friendly items."}
            db["4"] = {"name": "Free ECO Delivery", "points_needed": 8000, "description": "Free eco-friendly delivery."}
    app.run(debug=True)
