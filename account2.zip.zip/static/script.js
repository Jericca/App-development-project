document.addEventListener("DOMContentLoaded", function () {
    console.log("JavaScript Loaded");

    // Signup Form Validation and Submission (fetch-based)
    const signupForm = document.querySelector("#signup-form");
    if (signupForm) {
        signupForm.addEventListener("submit", async function (event) {
            event.preventDefault(); // Prevent default form submission

            const formData = new FormData(event.target);
            const confirmPassword = document.getElementById("confirmPassword")?.value.trim();

            // Basic validation
            if (!formData.get("username") || !formData.get("email") || !formData.get("password") || !confirmPassword) {
                alert("Please fill out all fields.");
                return;
            }

            // Email validation
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (!emailPattern.test(formData.get("email"))) {
                alert("Please enter a valid email address.");
                return;
            }

            // Password length validation
            if (formData.get("password").length < 8) {
                alert("Password must be at least 8 characters long.");
                return;
            }

            // Password match validation
            if (formData.get("password") !== confirmPassword) {
                alert("Passwords do not match.");
                return;
            }

            // Submit form data via fetch
            try {
                const response = await fetch(event.target.action, {
                    method: "POST",
                    body: formData,
                });

                const result = await response.json();

                const messageContainer = document.getElementById("message-container");
                if (result.status === "success") {
                    messageContainer.innerHTML = `<p class="success">${result.message}</p>`;
                    setTimeout(() => {
                        window.location.replace("/login"); // Redirect to login
                    }, 2000);
                } else {
                    messageContainer.innerHTML = `<p class="error">${result.message}</p>`;
                }
            } catch (error) {
                console.error("Error during form submission:", error);
                document.getElementById("message-container").innerHTML = `<p class="error">An unexpected error occurred.</p>`;
            }
        });
    }

document.addEventListener('DOMContentLoaded', function() {
    const forgotPasswordLink = document.getElementById('forgot-password-link');

    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent the default link behavior (navigation)
            window.location.href = 'forget-password.html'; // Redirect to the forgot password page
        });
    }
});

// Ensure the script is executed only after the page fully loads
document.addEventListener("DOMContentLoaded", function() {
    // Get the "Continue as Guest" button by its ID
    const guestButton = document.getElementById('guest-button');

     // Add a click event listener to redirect to the home.html file
     guestButton.addEventListener('click', function() {
        window.location.assign('/static/home.html'); // Replace with the correct path to home.html
     });
});

    // Home Page Logic for Dynamic Profile Info
    if (window.location.pathname.includes("home") || window.location.pathname === "/") {
        const params = new URLSearchParams(window.location.search);
        const name = params.get("name");
        const email = params.get("email");
        const img = params.get("img");

        if (name && email && img) {
            const profilePic = document.getElementById("profile-pic");
            const accountName = document.getElementById("account-name");
            const accountEmail = document.getElementById("account-email");

            if (profilePic) profilePic.src = img;
            if (accountName) accountName.textContent = `Welcome, ${name}`;
            if (accountEmail) accountEmail.textContent = email;
        } else {
            document.body.innerHTML = "<h2>No account details found. Please log in again.</h2>";
        }
    }
});

document.addEventListener("DOMContentLoaded", function () {
    const inputs = document.querySelectorAll("input");

    inputs.forEach(input => {
        if (input.value === "not added") {
            input.value = "";
        }
    });
});

function enableEdit(field) {
            document.getElementById(field + "_text").style.display = "none";
            document.getElementById(field + "_input").style.display = "inline-block";
            document.getElementById(field + "_save").style.display = "inline-block";
            document.getElementById(field + "_edit").style.display = "none";
}

$(document).ready(function(){
    $('.update-link').click(function(e){
        e.preventDefault();

        // Get the field that needs to be updated
        const field = $(this).data('field');
        const value = $('#' + field).val();

        // Make sure the URL is correctly pointing to the /manage_profile route
        $.ajax({
            url: "{{ url_for('manage_profile') }}",  // Ensure this matches the Flask route
            method: 'POST',
            data: {
                field: field,
                value: value,
                csrf_token: $('input[name="csrf_token"]').val()  // Include CSRF token if required
            },
            success: function(response) {
                alert(field + ' updated successfully.');
            },
            error: function(xhr) {
                alert('Error updating ' + field + '.');
            }
        });
    });
});

$.ajax({
    url: "{{ url_for('manage_profile') }}",  // Correct Flask route URL
    method: 'POST',  // POST method to update profile
    data: {
        field: field,
        value: value,
        csrf_token: $('input[name="csrf_token"]').val()  // Include CSRF token if necessary
    },
    success: function(response) {
        alert(field + ' updated successfully.');
    },
    error: function(xhr) {
        alert('Error updating ' + field + '.');
    }
});

document.addEventListener("DOMContentLoaded", function () {
    console.log("Dropdown script loaded!"); // Debugging check

    document.querySelectorAll(".notif-section1, .notif-section2").forEach(section => {
        section.addEventListener("click", function (event) {
            console.log("Clicked on:", this); // Debugging check
            event.stopPropagation();

            let dropdown = this.querySelector(".notif-dropdown");

            if (dropdown) {
                console.log("Dropdown found:", dropdown); // Debugging check

                // Add a slight delay to visually debug toggle behavior
                setTimeout(() => {
                    dropdown.classList.toggle("hidden");
                    console.log("Dropdown visibility toggled.");
                }, 100);
            } else {
                console.warn("No dropdown found inside this section.");
            }
        });
    });
});