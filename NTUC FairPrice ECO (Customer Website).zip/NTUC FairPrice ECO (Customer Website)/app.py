from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import shelve
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Mock user data
user_data = {"username": "johnny", "points": 5600}


@app.route('/', methods=['GET', 'POST'])
def rewards():
    filter_option = request.args.get('filter', 'default')  # Get filter option from query params

    # Open vouchers and wallet shelve databases
    with shelve.open('vouchers.db') as vouchers_db, shelve.open('wallet.db', writeback=True) as wallet_db:
        # Load vouchers
        vouchers = {key: {**value, "points_needed": int(value["points_needed"])} for key, value in vouchers_db.items()}

        # Initialize wallet if it doesn't exist
        if user_data['username'] not in wallet_db:
            wallet_db[user_data['username']] = {"points": user_data['points'], "vouchers": [], "transactions": []}

        # Load user wallet
        wallet = wallet_db[user_data['username']]

    # Apply filters
    if filter_option == 'lowest_to_highest':
        vouchers = dict(sorted(vouchers.items(), key=lambda item: item[1]['points_needed']))
    elif filter_option == 'highest_to_lowest':
        vouchers = dict(sorted(vouchers.items(), key=lambda item: item[1]['points_needed'], reverse=True))
    elif filter_option == 'sufficient_points':
        vouchers = {key: value for key, value in vouchers.items() if wallet['points'] >= value['points_needed']}

    return render_template('rewards.html', vouchers=vouchers, wallet=wallet, filter_option=filter_option)


@app.route('/redeem/<voucher_name>', methods=['POST'])
def redeem(voucher_id):
    with shelve.open('vouchers.db') as vouchers_db, shelve.open('wallet.db', writeback=True) as wallet_db:
        voucher = vouchers_db.get(voucher_id)
        if not voucher:
            return jsonify({"status": "error", "message": "Voucher not found"})

        # Load user wallet
        wallet = wallet_db[user_data['username']]

        # Check if points are sufficient
        if wallet['points'] < voucher['points_needed']:
            return jsonify({"status": "error", "message": "Not enough points to redeem this voucher"})

        # Check if voucher is already redeemed
        if any(v['name'] == voucher['name'] for v in wallet['vouchers']):
            return jsonify({"status": "error", "message": "Voucher already redeemed"})

        # Deduct points and add the voucher to the wallet
        wallet['points'] -= voucher['points_needed']
        voucher["redeemed_date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        voucher["expiry_date"] = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")  # Expiry date is 30 days from now
        wallet['vouchers'].append(voucher)

        # Add a transaction record
        wallet['transactions'].append({
            "type": "redeemed",
            "voucher": voucher["name"],
            "points": voucher["points_needed"],
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })

        wallet_db[user_data['username']] = wallet

    return jsonify({"status": "success", "message": f"Voucher '{voucher['name']}' redeemed successfully", "remaining_points": wallet['points']})


@app.route('/wallet')
def wallet():
    with shelve.open('wallet.db') as wallet_db:
        # Ensure wallet exists for the user
        wallet = wallet_db.get(user_data['username'], {"vouchers": [], "transactions": []})
        current_vouchers = wallet.get("vouchers", [])
        past_transactions = wallet.get("transactions", [])
    return render_template('wallet.html', current_vouchers=current_vouchers, past_transactions=past_transactions)


@app.route('/events')
def events():
    return render_template('events.html')


if __name__ == '__main__':
    with shelve.open('vouchers.db', writeback=True) as db:
        if not db:
            db["1"] = {"name": "$2 FairPrice ECO Voucher", "points_needed": 1000, "description": "$2 voucher for eco-friendly items."}
            db["2"] = {"name": "$5 FairPrice ECO Voucher", "points_needed": 2600, "description": "$5 voucher for eco-friendly items."}
            db["3"] = {"name": "$10 FairPrice ECO Voucher", "points_needed": 5100, "description": "$10 voucher for eco-friendly items."}
            db["4"] = {"name": "Free ECO Delivery", "points_needed": 8000, "description": "Free eco-friendly delivery."}
    app.run(debug=True)
