document.querySelector('.login-form').addEventListener('submit', function(event) {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (email === '' || password === '') {
        alert('Please fill in both fields.');
        event.preventDefault();  // Prevent form submission
    }
});

document.getElementById('signUpButton').addEventListener('click', function() {
    window.location.href = 'signup.html'; // Replace with the actual URL
});

document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting automatically

    // Get the values of form fields
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    // Basic validation
    if (!firstName || !lastName || !email || !phone || !password || !confirmPassword) {
        alert('Please fill out all fields.');
        return;
    }

    // Validate that the passwords match
    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return;
    }

    // If all validation passes
    alert('Sign up successful! Redirecting...');
    
    // Redirect to another page (for example, a welcome page)
    window.location.href = 'welcome.html'; // Change 'welcome.html' to your actual redirect target
});
