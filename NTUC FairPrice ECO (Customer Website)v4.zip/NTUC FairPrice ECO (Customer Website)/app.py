from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
import requests
import shelve
from datetime import datetime
from fpdf import FPDF
import os
import random
import string

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for flashing messages

# Base URL for the staff backend API
STAFF_BACKEND_URL = "http://127.0.0.1:5001/api/vouchers"

@app.route('/')
def rewards():
    username = session.get("username", "johnny")
    filter_option = request.args.get('filter', 'default')

    # ✅ Fetch vouchers from the staff API
    response = requests.get(STAFF_BACKEND_URL)
    vouchers = response.json() if response.status_code == 200 else {}

    # ✅ Fetch user data
    with shelve.open('users.db', writeback=True) as users_db:
        user = users_db.get(username, {"points": 0, "redeemed_vouchers": []})
        user_points = user.get("points", 0)

    # ✅ Apply Filters
    if filter_option == 'lowest_to_highest':
        vouchers = dict(sorted(vouchers.items(), key=lambda item: int(item[1]['points_needed'])))
    elif filter_option == 'highest_to_lowest':
        vouchers = dict(sorted(vouchers.items(), key=lambda item: int(item[1]['points_needed']), reverse=True))
    elif filter_option == 'sufficient_points':
        vouchers = {key: value for key, value in vouchers.items() if user_points >= int(value['points_needed'])}

    return render_template('rewards.html', vouchers=vouchers, user_points=user_points, filter_option=filter_option)

@app.route('/download_all_vouchers')
def download_all_vouchers():
    username = session.get("username", "johnny")

    with shelve.open('users.db') as users_db:
        user = users_db.get(username, {"redeemed_vouchers": []})
        redeemed_vouchers = user.get("redeemed_vouchers", [])

    if not redeemed_vouchers:
        flash("No redeemed vouchers available to download.", "warning")
        return redirect(url_for('view_vouchers'))

    # ✅ Create PDF with improved styling
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # ✅ Add company logo (Ensure 'Fairprice_logo.png' is in the static/images folder)
    logo_path = "static/images/Fairprice (logo).png"
    if os.path.exists(logo_path):
        pdf.image(logo_path, 10, 8, 40)  # Position (x=10, y=8), Width=40

    # ✅ User-specific title
    pdf.set_font("Arial", "B", 18)
    pdf.cell(200, 15, f"{username.capitalize()}'s Redeemed Vouchers", ln=True, align="C")
    pdf.ln(10)

    # ✅ Table headers with better formatting
    pdf.set_font("Arial", "B", 12)
    pdf.set_fill_color(50, 205, 50)  # Green header background
    pdf.set_text_color(255)  # White text
    pdf.cell(70, 10, "Voucher Name", border=1, align="C", fill=True)
    pdf.cell(25, 10, "Points", border=1, align="C", fill=True)
    pdf.cell(35, 10, "Redeemed Date", border=1, align="C", fill=True)
    pdf.cell(35, 10, "Expiry Date", border=1, align="C", fill=True)
    pdf.cell(30, 10, "Voucher Code", border=1, align="C", fill=True)
    pdf.ln()

    # ✅ Reset text color for table data
    pdf.set_text_color(0)  # Black text
    pdf.set_font("Arial", size=12)

    # ✅ Populate table rows with voucher data
    for voucher in redeemed_vouchers:
        pdf.cell(70, 10, voucher["name"], border=1)
        pdf.cell(25, 10, str(voucher["points_needed"]), border=1, align="C")
        pdf.cell(35, 10, voucher["redeemed_date"], border=1, align="C")
        pdf.cell(35, 10, voucher["expiry_date"], border=1, align="C")
        pdf.cell(30, 10, voucher["code"], border=1, align="C")  # ✅ Include voucher code
        pdf.ln()

    # ✅ Save and send the PDF
    pdf_filename = f"{username}_redeemed_vouchers.pdf"
    pdf.output(pdf_filename)

    return send_file(pdf_filename, as_attachment=True)



@app.route('/view_vouchers', methods=['GET', 'POST'])
def view_vouchers():
    username = session.get("username", "johnny")
    sort_by = request.args.get('sort_by', 'default')
    expiring_soon = []

    response = requests.get(STAFF_BACKEND_URL)
    staff_vouchers = response.json() if response.status_code == 200 else {}

    with shelve.open('users.db', writeback=True) as users_db:
        user = users_db.get(username, {"redeemed_vouchers": []})
        redeemed_vouchers = user.get("redeemed_vouchers", [])
        expired_vouchers = []

        for voucher in redeemed_vouchers:
            voucher_id = voucher["voucher_id"]

            # ✅ Ensure correct voucher name is synced from staff backend
            if voucher_id in staff_vouchers:
                staff_voucher = staff_vouchers[voucher_id]
                voucher["name"] = staff_voucher["voucher_name"]  # ✅ Fix name mismatch
                voucher["expiry_date"] = staff_voucher["expiry_date"]
                voucher["expiry_time"] = staff_voucher.get("expiry_time", "23:59")
                voucher["points_needed"] = staff_voucher["points_needed"]
            else:
                expired_vouchers.append(voucher_id)

            expiry_datetime_str = f"{voucher['expiry_date']} {voucher['expiry_time']}"
            try:
                expiry_datetime = datetime.strptime(expiry_datetime_str, "%Y-%m-%d %H:%M")
                now = datetime.now()

                time_remaining = expiry_datetime - now
                if time_remaining.total_seconds() > 0:
                    days_remaining = time_remaining.days
                    voucher["time_remaining"] = f"{days_remaining}d {time_remaining.seconds // 3600}h"

                    if days_remaining < 3:
                        expiring_soon.append({
                            "voucher_name": voucher["name"],
                            "expiry_datetime": expiry_datetime.strftime("%Y-%m-%d %H:%M:%S"),
                            "voucher_id": voucher_id
                        })
                else:
                    voucher["time_remaining"] = "Expired"
                    expired_vouchers.append(voucher_id)

            except ValueError:
                voucher["time_remaining"] = "Invalid Date"

        if expired_vouchers:
            user["redeemed_vouchers"] = [v for v in redeemed_vouchers if v["voucher_id"] not in expired_vouchers]
            users_db[username] = user
            flash(f"{len(expired_vouchers)} expired or deleted vouchers have been removed.", "warning")

        if sort_by == "points":
            redeemed_vouchers.sort(key=lambda v: int(v.get("points_needed", 0)))
        elif sort_by == "expiry":
            redeemed_vouchers.sort(
                key=lambda v: datetime.strptime(f"{v['expiry_date']} {v['expiry_time']}", "%Y-%m-%d %H:%M")
                if "expiry_date" in v and "expiry_time" in v else datetime.max
            )

    return render_template('view_vouchers.html', redeemed_vouchers=redeemed_vouchers, expiring_soon=expiring_soon, sort_by=sort_by)

@app.route('/redeem/<string:voucher_id>', methods=['POST'])
def redeem(voucher_id):
    username = session.get("username", "johnny")  # Example user

    def generate_voucher_code():
        """Generate a random 6-character alphanumeric voucher code."""
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

    # ✅ Fetch the latest voucher data from the staff backend
    response = requests.get(STAFF_BACKEND_URL)
    staff_vouchers = response.json() if response.status_code == 200 else {}

    with shelve.open('users.db', writeback=True) as users_db:
        user = users_db.get(username, {"redeemed_vouchers": []})

        # ✅ Ensure the voucher exists in the staff backend before redeeming
        if voucher_id not in staff_vouchers:
            flash("Voucher not found in the staff system.", "error")
            return redirect(url_for('rewards'))

        staff_voucher = staff_vouchers[voucher_id]

        # ✅ Store correct voucher details from staff backend
        redeemed_voucher = {
            "voucher_id": voucher_id,
            "name": staff_voucher["voucher_name"],  # ✅ Ensure correct voucher name
            "points_needed": staff_voucher["points_needed"],
            "expiry_date": staff_voucher["expiry_date"],
            "expiry_time": staff_voucher.get("expiry_time", "23:59"),
            "redeemed_date": datetime.now().strftime("%Y-%m-%d"),
            "redeemed_time": datetime.now().strftime("%H:%M:%S"),
            "code": generate_voucher_code()
        }

        user["redeemed_vouchers"].append(redeemed_voucher)
        users_db[username] = user  # ✅ Save updated redeemed vouchers list

    flash("Voucher redeemed successfully!", "success")
    return redirect(url_for('view_vouchers'))  # ✅ Redirect to view updated vouchers


@app.route('/events')
def events():
    return render_template('events.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)  # Running client on port 5000







