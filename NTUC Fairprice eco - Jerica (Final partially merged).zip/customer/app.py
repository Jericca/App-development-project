from flask import Flask, render_template, request, redirect, url_for, session,flash
from flask_migrate import Migrate
import os
from werkzeug.utils import secure_filename
import re
from database import db


app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Setup the SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///products.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
migrate = Migrate(app, db)
tag = ["Best Seller", "Promotion", "Recommended"]
app.config['UPLOAD_FOLDER'] = 'static/uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
# Product Model:
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200), nullable=True)
    tags = db.Column(db.String(200), nullable=True)
    image = db.Column(db.String(200), nullable=True)
    co2_saved = db.Column(db.Float, nullable=True)  # Add this field
    quantity = db.Column(db.Float, nullable=True)  # Add this field


    def __repr__(self):
        return f"Product('{self.name}', '{self.price}')"

# Home page - Display all products
@app.route('/')
def index():
    try:
        products = Product.query.all()
        for product in products:
            if product.tags and isinstance(product.tags, str):
                product.tags = [tag.strip() for tag in product.tags.split(',')]  # Ensure proper list format

        return render_template('index.html', products=products)
    except Exception as e:
        return f"Error fetching products: {e}"


@app.route('/category/<category_name>')
def category_page(category_name):
    try:
        # Ensure case-insensitive category matching
        products = Product.query.filter(Product.tags.ilike(category_name)).all()
        for product in products:
            if product.tags and isinstance(product.tags, str):
                product.tags = [tag.strip() for tag in product.tags.split(',')]  # Ensure proper list format
        # Render the respective category page
        return render_template('category.html', category_name=category_name, products=products)
    except Exception as e:
        return f"Error fetching products: {e}"

# Add Product
@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        try:
            name = request.form['name'].strip()
            price = request.form['price']
            description = request.form['description'].strip()
            tags = request.form.getlist('tags')  # Get tags as a list
            tags = ", ".join(tags)  # Convert list to a comma-separated string
            image = request.files['image']
            co2_saved = request.form.get('co2_saved')
            quantity = request.form.get('quantity')

            if not name or not price or not co2_saved:
                flash("All fields are required.", "error")
                return redirect(url_for('add_product'))

            if not re.match("^[A-Za-z ]+$", name):
                flash("Invalid product name!", "error")
                return redirect(url_for('add_product'))

            # Check if name and price are valid
            if not name or not price:
                return "Name and price are required", 400
            try:

                price = float(price)
                co2_saved = float(co2_saved)
                quantity = float(quantity)
                if price < 0 or co2_saved < 0 or quantity < 0:
                    flash("Price, CO2 Saved, and Quantity cannot be negative.", "error")
                    return redirect(url_for('add_product'))
            except ValueError:
                flash("Price, CO2 Saved, and Quantity must be valid numbers.", "error")
                return redirect(url_for('add_product'))


            # Check for duplicates
            if Product.query.filter_by(name=name).first():
                flash("Product with this name already exists.", "error")
                return redirect(url_for('add_product'))

            filename = secure_filename(image.filename)
            image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            new_product = Product(name=name, price=price, description=description, tags=tags, image=filename, co2_saved=co2_saved, quantity=quantity)
            db.session.add(new_product)
            db.session.commit()
            flash("Product added successfully!", "success")

            return redirect(url_for('category_page', category_name=tags.lower()))

            # return redirect(url_for('index'))
        except Exception as e:
            flash(f"Error adding product: {e}", "error")
            return redirect(url_for('add_product'))
    return render_template('add_product.html',tags=tag)

# Update Product
@app.route('/update_product/<int:id>', methods=['GET', 'POST'])
def update_product(id):
    try:
        product = Product.query.get(id)
        if not product:
            return "Product not found", 404

        if request.method == 'POST':
            try:
                product.name = request.form['name'].strip()
                product.price = float(request.form['price'])
                product.description = request.form['description'].strip()
                tags = request.form.getlist('tags')  # Get tags as a list
                tags = ", ".join(tags)  # Convert list to a comma-separated string
                image = request.files['image']
                product.quantity = float(request.form.get('quantity', product.quantity))  # Update or keep old value
                product.co2_saved = float(request.form.get('co2_saved', product.co2_saved))  # Update or keep old value

                if product.price < 0 or product.quantity < 0 or product.co2_saved < 0:
                    flash("Price, Quantity, and CO2 Saved cannot be negative.", "error")
                    return redirect(url_for('update_product', id=id))

                if image:
                    filename = secure_filename(image.filename)
                    image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    product.image = filename

                db.session.commit()
                flash("Product updated successfully!", "success")
                return redirect(url_for('index'))
            except ValueError:
                flash("Price, Quantity, and CO2 Saved must be valid numbers.", "error")
                return redirect(url_for('update_product', id=id))
            except Exception as e:
                flash(f"Error updating product: {e}", "error")
                return redirect(url_for('update_product', id=id))

        return render_template('update_product.html', product=product, tags=tag)
    except Exception as e:
        return f"Error fetching product for update: {e}", 500

# Delete Product
@app.route('/delete_product/<int:id>')
def delete_product(id):
    try:
        product = Product.query.get(id)
        db.session.delete(product)
        db.session.commit()
        return redirect(url_for('index'))
    except Exception as e:
        return f"Error deleting product: {e}", 500

with app.app_context():
    db.create_all()
    print("Database tables created successfully!")

if __name__ == '__main__':
    app.run(debug=True, port=5001)
