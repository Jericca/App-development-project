from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
import requests
import shelve
import os
import random
import string
from datetime import datetime
from fpdf import FPDF
from database import db

app = Flask(__name__, template_folder="pages1")
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///products.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

STAFF_BACKEND_URL = "http://127.0.0.1:5001/api/vouchers"
# URL of the staff-side Flask app where FAQ data is served
STAFF_API_URL = 'http://localhost:5000/api/faqs'  # Replace with the correct address if deployed remotely


@app.route('/customer-faq', methods=['GET'])
def customer_faq():
    try:
        response = requests.get(STAFF_API_URL)
        response.raise_for_status()
        faqs = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching FAQ data: {e}")
        faqs = {}

    return render_template('customerfaq.html', faqs=faqs)


with app.app_context():
    db.create_all()

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200), nullable=True)
    tags = db.Column(db.String(200), nullable=True)
    image = db.Column(db.String(200), nullable=True)
    co2_saved = db.Column(db.Float, nullable=True)
    quantity = db.Column(db.Float, nullable=True)

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/main_page")
def main_page():
    products = Product.query.all()
    return render_template("main_page.html", products=products)

@app.route("/category/<category_name>")
def category_page(category_name):
    try:
        products = Product.query.filter(Product.tags.ilike(category_name)).all()
        return render_template('category_user.html', category_name=category_name, products=products)
    except Exception as e:
        return f"Error fetching products: {e}", 500

@app.route('/add_to_cart/<int:id>')
def add_to_cart(id):
    try:
        product = Product.query.get(id)
        if not product:
            return "Product not found", 404

        if 'carts' not in session:
            session['carts'] = {}

        product_id = str(id)
        session['carts'][product_id] = session['carts'].get(product_id, 0) + 1

        session.modified = True

        return redirect(request.referrer or url_for('home'))
    except Exception as e:
        return f"Error adding to cart: {e}", 500

@app.route('/cart')
def cart():
    try:
        cart_items = session.get('carts', {})

        if not cart_items:
            return render_template('carts.html', products=[])

        product_ids = list(map(int, cart_items.keys()))
        products = Product.query.filter(Product.id.in_(product_ids)).all()

        for product in products:
            product.quantity_in_cart = cart_items.get(str(product.id), 0)

        return render_template('carts.html', products=products)
    except Exception as e:
        return f"Error fetching cart products: {e}", 500

@app.route('/clear_cart')
def clear_cart():
    try:
        session.pop('carts', None)
        return redirect(url_for('cart'))
    except Exception as e:
        return f"Error clearing cart: {e}", 500

@app.route('/delete_product/<int:id>')
def delete_product(id):
    try:
        if 'carts' in session and str(id) in session['carts']:
            del session['carts'][str(id)]
            session.modified = True

        return redirect(url_for('cart'))
    except Exception as e:
        return f"Error deleting product from cart: {e}", 500


@app.route('/rewards')
def rewards():
    username = session.get("username", "johnny")  # Default user is Johnny
    filter_option = request.args.get('filter', 'default')

    # Fetch vouchers from backend
    response = requests.get(STAFF_BACKEND_URL)
    vouchers = response.json() if response.status_code == 200 else {}

    with shelve.open('users.db', writeback=True) as users_db:
        # Ensure Johnny exists in the database and has 9888 points if missing
        if username not in users_db:
            users_db[username] = {"points": 9888, "redeemed_vouchers": []}

        user = users_db[username]

        # Ensure the 'points' key exists and is set to 9888 if it's missing
        if "points" not in user:
            user["points"] = 9888
            users_db[username] = user  # Save updated data

        user_points = user["points"]  # Retrieve Johnny’s points

    # Apply filters for sorting or showing only redeemable vouchers
    if filter_option == 'lowest_to_highest':
        vouchers = dict(sorted(vouchers.items(), key=lambda item: int(item[1]['points_needed'])))
    elif filter_option == 'highest_to_lowest':
        vouchers = dict(sorted(vouchers.items(), key=lambda item: int(item[1]['points_needed']), reverse=True))
    elif filter_option == 'sufficient_points':
        vouchers = {key: value for key, value in vouchers.items() if user_points >= int(value['points_needed'])}

    return render_template('rewards.html', vouchers=vouchers, user_points=user_points, filter_option=filter_option)


@app.route('/view_vouchers', methods=['GET', 'POST'])
def view_vouchers():
    username = session.get("username", "johnny")
    sort_by = request.args.get('sort_by', 'default')
    expiring_soon = []

    response = requests.get(STAFF_BACKEND_URL)
    staff_vouchers = response.json() if response.status_code == 200 else {}

    with shelve.open('users.db', writeback=True) as users_db:
        user = users_db.get(username, {"points": 9888, "redeemed_vouchers": []})  # Ensure Johnny has 9888 points
        user_points = user.get("points", 9888)  # Retrieve Johnny’s points

        session['points'] = user_points  # ✅ Update session to match actual user points

        redeemed_vouchers = user.get("redeemed_vouchers", [])
        expired_vouchers = []

        for voucher in redeemed_vouchers:
            voucher_id = voucher["voucher_id"]

            if voucher_id in staff_vouchers:
                staff_voucher = staff_vouchers[voucher_id]
                voucher["name"] = staff_voucher["voucher_name"]
                voucher["expiry_date"] = staff_voucher["expiry_date"]
                voucher["expiry_time"] = staff_voucher.get("expiry_time", "23:59")
                voucher["points_needed"] = staff_voucher["points_needed"]
            else:
                expired_vouchers.append(voucher_id)

            expiry_datetime_str = f"{voucher['expiry_date']} {voucher['expiry_time']}"
            try:
                expiry_datetime = datetime.strptime(expiry_datetime_str, "%Y-%m-%d %H:%M")
                now = datetime.now()

                time_remaining = expiry_datetime - now
                if time_remaining.total_seconds() > 0:
                    days_remaining = time_remaining.days
                    voucher["time_remaining"] = f"{days_remaining}d {time_remaining.seconds // 3600}h"

                    if days_remaining < 3:
                        expiring_soon.append({
                            "voucher_name": voucher["name"],
                            "expiry_datetime": expiry_datetime.strftime("%Y-%m-%d %H:%M:%S"),
                            "voucher_id": voucher_id
                        })
                else:
                    voucher["time_remaining"] = "Expired"
                    expired_vouchers.append(voucher_id)

            except ValueError:
                voucher["time_remaining"] = "Invalid Date"

        if expired_vouchers:
            user["redeemed_vouchers"] = [v for v in redeemed_vouchers if v["voucher_id"] not in expired_vouchers]
            users_db[username] = user
            session['points'] = user["points"]  # ✅ Ensure session is always updated
            flash(f"{len(expired_vouchers)} expired or deleted vouchers have been removed.", "warning")

        if sort_by == "points":
            redeemed_vouchers.sort(key=lambda v: int(v.get("points_needed", 0)))
        elif sort_by == "expiry":
            redeemed_vouchers.sort(
                key=lambda v: datetime.strptime(f"{v['expiry_date']} {v['expiry_time']}", "%Y-%m-%d %H:%M")
                if "expiry_date" in v and "expiry_time" in v else datetime.max
            )

    return render_template('view_vouchers.html', redeemed_vouchers=redeemed_vouchers, expiring_soon=expiring_soon, sort_by=sort_by, user_points=session['points'])  # ✅ Pass session['points'] to ensure it's updated



@app.route('/download_all_vouchers')
def download_all_vouchers():
    username = session.get("username", "johnny")

    with shelve.open('users.db') as users_db:
        user = users_db.get(username, {"redeemed_vouchers": []})
        redeemed_vouchers = user.get("redeemed_vouchers", [])

    if not redeemed_vouchers:
        flash("No redeemed vouchers available to download.", "warning")
        return redirect(url_for('view_vouchers'))

    # ✅ Create PDF with improved styling
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # ✅ Add company logo (Ensure 'Fairprice_logo.png' is in the static/images folder)
    logo_path = "static/images/Fairprice (logo).png"
    if os.path.exists(logo_path):
        pdf.image(logo_path, 10, 8, 40)  # Position (x=10, y=8), Width=40

    # ✅ User-specific title
    pdf.set_font("Arial", "B", 18)
    pdf.cell(200, 15, f"{username.capitalize()}'s Redeemed Vouchers", ln=True, align="C")
    pdf.ln(10)

    # ✅ Table headers with better formatting
    pdf.set_font("Arial", "B", 12)
    pdf.set_fill_color(50, 205, 50)  # Green header background
    pdf.set_text_color(255)  # White text
    pdf.cell(70, 10, "Voucher Name", border=1, align="C", fill=True)
    pdf.cell(25, 10, "Points", border=1, align="C", fill=True)
    pdf.cell(35, 10, "Redeemed Date", border=1, align="C", fill=True)
    pdf.cell(35, 10, "Expiry Date", border=1, align="C", fill=True)
    pdf.cell(30, 10, "Voucher Code", border=1, align="C", fill=True)
    pdf.ln()

    # ✅ Reset text color for table data
    pdf.set_text_color(0)  # Black text
    pdf.set_font("Arial", size=12)

    # ✅ Populate table rows with voucher data
    for voucher in redeemed_vouchers:
        pdf.cell(70, 10, voucher["name"], border=1)
        pdf.cell(25, 10, str(voucher["points_needed"]), border=1, align="C")
        pdf.cell(35, 10, voucher["redeemed_date"], border=1, align="C")
        pdf.cell(35, 10, voucher["expiry_date"], border=1, align="C")
        pdf.cell(30, 10, voucher["code"], border=1, align="C")  # ✅ Include voucher code
        pdf.ln()

    # ✅ Save and send the PDF
    pdf_filename = f"{username}_redeemed_vouchers.pdf"
    pdf.output(pdf_filename)

    return send_file(pdf_filename, as_attachment=True)

@app.route('/redeem/<string:voucher_id>', methods=['POST'])
def redeem(voucher_id):
    username = session.get("username", "johnny")  # Example user

    def generate_voucher_code():
        """Generate a random 6-character alphanumeric voucher code."""
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

    # ✅ Fetch the latest voucher data from the staff backend
    response = requests.get(STAFF_BACKEND_URL)
    staff_vouchers = response.json() if response.status_code == 200 else {}

    with shelve.open('users.db', writeback=True) as users_db:
        user = users_db.get(username, {"points": 9888, "redeemed_vouchers": []})

        # ✅ Ensure the voucher exists in the staff backend before redeeming
        if voucher_id not in staff_vouchers:
            flash("Voucher not found in the staff system.", "error")
            return redirect(url_for('rewards'))

        staff_voucher = staff_vouchers[voucher_id]
        voucher_cost = int(staff_voucher["points_needed"])

        # ✅ Check if user has enough points before redeeming
        if user["points"] < voucher_cost:
            flash("Not enough points to redeem this voucher!", "error")
            return redirect(url_for('rewards'))

        # ✅ Deduct points from user after successful redemption
        user["points"] -= voucher_cost
        users_db[username] = user  # ✅ Save updated points in the database

        session['points'] = user["points"]  # ✅ Update session points to reflect the new balance

        # ✅ Store correct voucher details from staff backend
        redeemed_voucher = {
            "voucher_id": voucher_id,
            "name": staff_voucher["voucher_name"],  # ✅ Ensure correct voucher name
            "points_needed": voucher_cost,
            "expiry_date": staff_voucher["expiry_date"],
            "expiry_time": staff_voucher.get("expiry_time", "23:59"),
            "redeemed_date": datetime.now().strftime("%Y-%m-%d"),
            "redeemed_time": datetime.now().strftime("%H:%M:%S"),
            "code": generate_voucher_code()
        }

        user["redeemed_vouchers"].append(redeemed_voucher)

    flash("Voucher redeemed successfully!", "success")
    return redirect(url_for('view_vouchers'))  # ✅ Redirect to view updated vouchers

@app.route('/events')
def events():
    return render_template('events.html')

def search_database(query):
    query = query.lower()  # Convert query to lowercase for case-insensitive search
    data = {
        "vegetables": ["potato", "carrot", "corn", "broccoli"],
        "fruits": ["apple", "banana", "mango"],
        "events": ["farmers market", "discount sale", "cooking class"]
    }

    results = {
        "vegetables": [item for item in data["vegetables"] if query in item],
        "fruits": [item for item in data["fruits"] if query in item],
        "events": [event for event in data["events"] if query in event]
    }

    return results

@app.route('/search_results')
def search_results():
    query = request.args.get('q', '')
    # Process the search query for events, categories, or items
    results = search_database(query)  # Implement this function to return relevant results
    return render_template("search_results.html", query=query, results=results)

def get_user_info(username):
    """Fetch user information from user.db"""
    with shelve.open('user.db') as users_db:
        return users_db.get(username, {"username": "Johnny", "points": 9888})

@app.route('/login')
def login():
    """Simulating a login where user details are retrieved from user.db"""
    username = "Johnny"  # Example user
    user_data = get_user_info(username)  # Fetch user details

    session['username'] = user_data['username']
    session['points'] = user_data['points']

    return redirect(url_for('home'))  # Redirect to home page

@app.route('/logout')
def logout():
    """Clears the session on logout"""
    session.pop('username', None)
    session.pop('points', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
