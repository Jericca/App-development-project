document.addEventListener("DOMContentLoaded", () => {
    const accordionItems = document.querySelectorAll(".accordion-item");
    const manageFaqsBtn = document.getElementById("manage-faqs-btn");
    const modalOverlay = document.getElementById("modal-overlay");
    const faqForm = document.getElementById("faq-form");
    const faqIdField = document.getElementById("faq-id");
    const questionField = document.getElementById("question");
    const answerField = document.getElementById("answer");
    const saveFaqBtn = document.getElementById("save-faq-btn");
    const faqList = document.getElementById("faq-list");
    const closeModalBtn = document.getElementById("close-modal-btn");

    // Search Functionality
    document.addEventListener("DOMContentLoaded", () => {
        const searchInput = document.getElementById("searchInput");
        const accordionItems = document.querySelectorAll(".accordion-item");
    
        // Listen for input events on the search bar
        searchInput.addEventListener("input", () => {
            const searchTerm = searchInput.value.toLowerCase().trim(); // Normalize input
            console.log("Search term:", searchTerm); // Debugging: Log the search term
    
            accordionItems.forEach(item => {
                const question = item.getAttribute("data-question"); // Get the data-question attribute
                if (question && question.includes(searchTerm)) {
                    item.style.display = "block"; // Show matching items
                } else {
                    item.style.display = "none"; // Hide non-matching items
                }
            });
        });
    });
    

    // Accordion functionality
    accordionItems.forEach(item => {
        const header = item.querySelector(".accordion-header");
        const content = item.querySelector(".accordion-content");

        header.addEventListener("click", () => {
            const isActive = item.classList.toggle("active");

            if (isActive) {
                // Set max-height to the scrollHeight for smooth animation
                content.style.maxHeight = content.scrollHeight + "px";
            } else {
                // Collapse content
                content.style.maxHeight = "0";
            }

            // Close other accordions (optional)
            accordionItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains("active")) {
                    otherItem.classList.remove("active");
                    const otherContent = otherItem.querySelector(".accordion-content");
                    otherContent.style.maxHeight = "0";
                }
            });
        });
    });

    // Open modal for adding a new FAQ
    manageFaqsBtn.addEventListener("click", () => {
        resetForm(); // Clear form on modal open
        modalOverlay.classList.add("active");
    });

    // Close modal
    closeModalBtn.addEventListener("click", () => {
        modalOverlay.classList.remove("active");
        resetForm(); // Reset form on modal close
    });

    // Handle Edit button click
    faqList.addEventListener("click", (e) => {
        if (e.target.classList.contains("edit-faq-btn")) {
            // Get the FAQ data from the button's dataset
            const faqId = e.target.dataset.id;
            const question = e.target.dataset.question;
            const answer = e.target.dataset.answer;

            // Ensure the data attributes are populated correctly
            if (faqId && question && answer) {
                // Populate the form with the existing FAQ data
                faqIdField.value = faqId;
                questionField.value = question;
                answerField.value = answer;

                // Update the save button to indicate edit mode
                saveFaqBtn.textContent = "Save Changes";

                // Open the modal
                modalOverlay.classList.add("active");
            } else {
                console.error("Edit button missing data attributes");
            }
        }
    });

    // Reset form for adding a new FAQ
    function resetForm() {
        faqIdField.value = ""; // Empty hidden field indicates a new FAQ
        questionField.value = "";
        answerField.value = "";
        saveFaqBtn.textContent = "Add FAQ"; // Reset button text
    }
    });

//File Upload
document.addEventListener("DOMContentLoaded", () => {
    const attachButton = document.getElementById("attachButton");
    const fileInput = document.getElementById("fileInput");

    // Trigger file input when paperclip icon is clicked
    attachButton.addEventListener("click", () => {
        fileInput.click();
    });

    // Handle file selection
    fileInput.addEventListener("change", () => {
        const file = fileInput.files[0];
        if (file) {
            // Display file name (optional)
            console.log(`Selected file: ${file.name}`);
            
            // Optionally send the file to the server
            const formData = new FormData();
            formData.append("file", file);

            // Example: Send file to backend
            fetch("/api/upload", {
                method: "POST",
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log("File uploaded successfully:", data);
                })
                .catch((error) => {
                    console.error("Error uploading file:", error);
                });
        }
    });
});

fileInput.addEventListener("change", () => {
    const file = fileInput.files[0];
    if (file) {
        const fileMessageElem = document.createElement("div");
        fileMessageElem.classList.add("message", "user");
        fileMessageElem.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: flex-end;">
                <p style="background: #d1e7dd; padding: 8px 12px; border-radius: 10px; margin-left: 10px; font-size: 14px; max-width: 70%; word-wrap: break-word;">
                    Uploaded file: <strong>${file.name}</strong>
                </p>
            </div>
        `;
        chatHistory.appendChild(fileMessageElem);
    }
});

// Speech-to-Text
document.addEventListener("DOMContentLoaded", () => {
    const micButton = document.getElementById("micButton");
    const userInput = document.getElementById("userInput");

    // Check if the browser supports the Web Speech API
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        alert("Speech recognition is not supported in this browser. Please try Chrome or Edge.");
        return;
    }

    // Initialize the SpeechRecognition object
    const recognition = new SpeechRecognition();
    recognition.lang = "en-US"; // Set the language
    recognition.interimResults = false; // Do not show interim results
    recognition.maxAlternatives = 1; // Limit to one best match

    // Start speech recognition when the microphone button is clicked
    micButton.addEventListener("click", () => {
        micButton.classList.add("active"); // Activate visual indicator
        recognition.start();
    });

    // Handle the speech recognition result
    recognition.addEventListener("result", (event) => {
        const transcript = event.results[0][0].transcript;
        userInput.value = transcript; // Set the recognized text in the input field
        console.log("Speech recognized:", transcript);
    });

    // Handle speech recognition errors
    recognition.addEventListener("error", (event) => {
        console.error("Speech recognition error:", event.error);
        alert("An error occurred during speech recognition. Please try again.");
    });

    // Provide feedback when speech recognition ends
    recognition.addEventListener("end", () => {
        micButton.classList.remove("active"); // Deactivate visual indicator
        console.log("Speech recognition ended.");
    });
});

// Chatbot script
document.addEventListener("DOMContentLoaded", () => {
    const chatbox = document.getElementById("chatbox");
    const chatToggle = document.getElementById("chatToggle");
    const closeChat = document.getElementById("closeChat");
    const chatHistory = document.getElementById("chatHistory");
    const userInput = document.getElementById("userInput");
    const sendMessageButton = document.getElementById("sendMessage");

    // Ensure the chatbox starts hidden
    chatbox.style.display = "none";

    // Toggle chatbox visibility
    if (chatToggle) {
        chatToggle.addEventListener("click", () => {
            chatbox.style.display = chatbox.style.display === "none" ? "flex" : "none";
        });
    }

    // Close chatbox
    if (closeChat) {
        closeChat.addEventListener("click", () => {
            chatbox.style.display = "none";
        });
    }

// Function to send a message
async function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    // Display user message with avatar
    const userMessageElem = document.createElement("div");
    userMessageElem.classList.add("message", "user");
    userMessageElem.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: flex-end;">
            <p style="background: #d1e7dd; padding: 8px 12px; border-radius: 10px; margin-left: 10px; font-size: 14px; max-width: 70%; word-wrap: break-word;">${message}</p>
            <img src="/static/user.png" alt="User Avatar" style="width: 25px; height: 25px; margin-left: 10px;">
        </div>
    `;
    chatHistory.appendChild(userMessageElem);

    try {
        // Send message to the backend
        const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message }),
        });

        if (!response.ok) throw new Error("Failed to fetch response from server.");

        const data = await response.json();

        // Display bot reply with avatar
        const botMessageElem = document.createElement("div");
        botMessageElem.classList.add("message", "bot");
        botMessageElem.innerHTML = `
            <div style="display: flex; align-items: center;">
                <img src="/static/melvin.png" alt="Bot Avatar" style="width: 30px; height: 30px; border-radius: 50%; margin-right: 10px;">
                <p style="background: #e9ecef; padding: 8px 12px; border-radius: 10px; font-size: 14px; max-width: 70%; word-wrap: break-word;">${data.reply}</p>
            </div>
        `;
        chatHistory.appendChild(botMessageElem);
    } catch (error) {
        console.error("Error sending message:", error);
        const errorMessageElem = document.createElement("div");
        errorMessageElem.classList.add("message", "bot");
        errorMessageElem.innerHTML = `
            <div style="display: flex; align-items: center;">
                <img src="/static/melvin.png" alt="Bot Avatar" style="width: 30px; height: 30px; border-radius: 50%; margin-right: 10px;">
                <p style="background: #e9ecef; padding: 8px 12px; border-radius: 10px; font-size: 14px; max-width: 70%; word-wrap: break-word;">Sorry, there was an error processing your request.</p>
            </div>
        `;
        chatHistory.appendChild(errorMessageElem);
    }

    // Scroll chat history to the bottom
    chatHistory.scrollTop = chatHistory.scrollHeight;

    // Clear input field and refocus
    userInput.value = "";
    userInput.focus();
}


    // Send message when the button is clicked
    if (sendMessageButton) {
        sendMessageButton.addEventListener("click", sendMessage);
    }

    // Send message when "Enter" is pressed in the input field
    if (userInput) {
        userInput.addEventListener("keypress", (event) => {
            if (event.key === "Enter") {
                event.preventDefault();
                sendMessage();
            }
        });
    }
});
