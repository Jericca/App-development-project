from flask import Flask, redirect, url_for, session
import os
from cart import cart_bp
import shelve


def get_user_id():
    # This helper is similar to the one in cart.py.
    user_id = session.get("user_id")
    if not user_id:
        user_id = "test_user"
        session["user_id"] = user_id
    return user_id

def get_cart():
    user_id = get_user_id()
    with shelve.open("cart.db", "c") as db:
        if user_id not in db:
            db[user_id] = []
        return db[user_id]

# Create the Flask app instance.
def create_app():
    app = Flask(__name__)
    app.secret_key = os.getenv('FLASK_SECRET_KEY', 'supersecretkey')

    # Add your Stripe keys to the config.
    app.config['STRIPE_PUBLIC_KEY'] = 'pk_test_51QTSLzCyJbY5AAxEudYBToGOui7aFXfkmqzzhWzH99EGDBOH2WSEbmSianjUY03qVJTBYJoweOUOTLZcYSrT8HLV00w6h6890j'
    app.config['STRIPE_SECRET_KEY'] = 'sk_test_51QTSLzCyJbY5AAxE6dOmuLulPFJftHRdiOWNojThkNRuym8eLfDCmSYyfFNz8CyGyzcPToftHXuStZFvU7Er4gtI00089HpIjx'

    # -----------------------------
    # CONTEXT PROCESSOR
    # -----------------------------
    @app.context_processor
    def inject_cart_item_count():
        """
        This context processor makes `cart_item_count` available in all templates.
        """
        cart = get_cart()
        cart_item_count = sum(item['qty'] for item in cart)
        return dict(cart_item_count=cart_item_count)

    # Register the cart blueprint
    app.register_blueprint(cart_bp, url_prefix='/cart')

    # Define a root route that redirects to the shopping cart page.
    @app.route('/')
    def index():
        return redirect(url_for('cart.shopping_cart'))

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
