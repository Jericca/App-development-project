from flask import Flask, Blueprint, render_template, request, redirect, url_for, session, flash, current_app, jsonify
import shelve
import stripe
from datetime import datetime, date, timedelta
import re
import random
import requests
import smtplib
from email.mime.text import MIMEText
import os
import csv

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # For session management

# -------------------------------------------------------------------------
# CART BLUEPRINT
# -------------------------------------------------------------------------
cart_bp = Blueprint("cart", __name__, template_folder="templates")

# -------------------------------------------------------------------------
# ROUTE for Address Autocomplete (Google Places API)
# -------------------------------------------------------------------------
GOOGLE_API_KEY = "AIzaSyCtiYid1o1IU8sExYzvO1rCU4bv8pqab5M"

def store_delivery_in_csv(delivery_data):
    """
    Saves the delivery_data dict to a CSV file (delivery_data.csv).
    If the file doesn't exist, it creates it and writes a header row.
    Then it appends a new row with the delivery details.
    """
    file_name = "delivery_data.csv"
    file_exists = os.path.exists(file_name)

    with open(file_name, mode="a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        # If file didn't exist, write the header row
        if not file_exists:
            headers = [
                "Postal Code",
                "Building Name",
                "Address",
                "Floor Number",
                "Unit Number",
                "Recipient Name",
                "Phone Number",
                "Delivery Date",
                "Delivery Time Slot",
                "Timestamp"
            ]
            writer.writerow(headers)
        # Create a row with delivery details and current timestamp
        row = [
            delivery_data.get("postalCode", ""),
            delivery_data.get("buildingName", ""),
            delivery_data.get("address", ""),
            delivery_data.get("floorNumber", ""),
            delivery_data.get("unitNumber", ""),
            delivery_data.get("recipientName", ""),
            delivery_data.get("phoneNumber", ""),
            delivery_data.get("deliveryDate", ""),
            delivery_data.get("deliveryTimeSlot", ""),
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ]
        writer.writerow(row)
        print(f"Delivery data appended to {file_name}")

@cart_bp.route("/get_addresses", methods=["GET"])
def get_addresses():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify([])

    endpoint = "https://maps.googleapis.com/maps/api/place/autocomplete/json"
    params = {
        "input": query,
        "components": "country:sg",  # Restrict to Singapore
        "types": "address",
        "key": GOOGLE_API_KEY
    }
    try:
        resp = requests.get(endpoint, params=params)
        data = resp.json()
        predictions = data.get("predictions", [])
        results = []
        for p in predictions:
            place_id = p.get("place_id")
            place_details = get_place_details(place_id, GOOGLE_API_KEY)
            postal_code   = place_details.get("postal_code", "")
            building_name = place_details.get("building_name", "")
            address       = place_details.get("formatted_address", p.get("description", ""))
            results.append({
                "postal_code": postal_code,
                "building_name": building_name,
                "address": address
            })
        return jsonify(results)
    except Exception as e:
        print("Error calling Google Places API:", e)
        return jsonify([])

def get_place_details(place_id, api_key):
    if not place_id:
        return {}
    details_url = "https://maps.googleapis.com/maps/api/place/details/json"
    params = {"place_id": place_id, "key": api_key}
    r = requests.get(details_url, params=params)
    details_data = r.json()
    result = details_data.get("result", {})
    address_components = result.get("address_components", [])
    postal_code = ""
    building_name = ""
    for comp in address_components:
        if "postal_code" in comp.get("types", []):
            postal_code = comp.get("long_name", "")
        if "premise" in comp.get("types", []):
            building_name = comp.get("long_name", "")
    formatted_address = result.get("formatted_address", "")
    name = result.get("name", "")
    return {
        "postal_code": postal_code,
        "building_name": building_name,
        "formatted_address": formatted_address,
        "name": name
    }

# -------------------------------------------------------------------------
# HELPER Functions
# -------------------------------------------------------------------------
def get_user_id():
    user_id = session.get("user_id")
    if not user_id:
        # Optionally flash a message or handle anonymous carts
        user_id = "test_user"
        session["user_id"] = user_id
    return user_id

def get_cart():
    user_id = get_user_id()
    with shelve.open("cart.db", "c") as db:
        if user_id not in db:
            db[user_id] = []
        return db[user_id]
    


def save_cart(cart):
    user_id = get_user_id()
    with shelve.open("cart.db", "c") as db:
        db[user_id] = cart

# -------------------------------------------------------------------------
# CART ROUTES
# -------------------------------------------------------------------------
@cart_bp.route('/contact')
def contact():
    return render_template('contact.html')

@cart_bp.route("/")
def shopping_cart():
    """
    Main cart page.
    """
    cart = get_cart()
    total_price = sum(item["price"] * item["qty"] for item in cart)
    total_items = sum(item["qty"] for item in cart)
    delivery_fee = 0 if total_price >= 60 else 5
    service_fee = 3.99

    # Determine discount based on voucher
    discount = 0
    voucher = session.get("voucher")
    if voucher:
        if voucher == "VOUCHER10":
            discount = 10
        elif voucher == "VOUCHER2":
            discount = 2

    final_total = total_price - discount + delivery_fee + service_fee
    # Points calculation
    points_received = sum(int(item.get("co2_saved", 0) * 100 * item["qty"]) for item in cart)

    return render_template(
        "cart.html",
        cart=cart,
        total_price=total_price,
        total_items=total_items,
        delivery_fee=delivery_fee,
        service_fee=service_fee,
        final_total=final_total,
        points_received=points_received,
        discount=discount
    )

@cart_bp.route("/add_item", methods=["GET", "POST"])
def add_item_page():
    """
    Simple page to add an item to the cart manually.
    """
    if request.method == "POST":
        item_name = request.form.get("name")
        item_price = request.form.get("price")
        item_qty = request.form.get("qty")
        item_img = request.form.get("img")
        item_co2 = request.form.get("co2", "0").strip()

        # Basic validation
        if not item_name or not item_price or not item_qty or not item_img:
            flash("All fields are required!", "danger")
            return redirect(url_for("cart.add_item_page"))
        try:
            item_price = float(item_price)
            item_qty = int(item_qty)
            item_co2 = float(item_co2)
        except ValueError:
            flash("Invalid price, quantity, or CO2 value!", "danger")
            return redirect(url_for("cart.add_item_page"))

        # Retrieve the cart and check if the item already exists
        cart = get_cart()
        item_found = None
        for item in cart:
            if item['name'] == item_name:
                item_found = item
                break

        # If the item already exists, increment quantity
        if item_found:
            item_found['qty'] += item_qty
        else:
            # Otherwise create a new item
            new_item = {
                "id": len(cart) + 1,
                "name": item_name,
                "price": item_price,
                "qty": item_qty,
                "img": item_img,
                "co2_saved": item_co2,
            }
            cart.append(new_item)

        # Save the updated cart
        save_cart(cart)

        flash("Item added to cart successfully!", "success")
        return redirect(url_for("cart.shopping_cart"))

    # If GET request, render the add_item form
    return render_template("add_item.html")
@cart_bp.route("/add_item_ajax", methods=["POST"])
def add_item_ajax():
    """
    Receives AJAX POST data, updates the cart, returns JSON with the new cart count.
    """
    try:
        item_name = request.form.get("name")
        item_price = request.form.get("price")
        item_qty = request.form.get("qty")
        item_img = request.form.get("img")
        item_co2 = request.form.get("co2", "0").strip()

        if not all([item_name, item_price, item_qty, item_img]):
            return jsonify({"error": "Missing fields"}), 400

        # Convert to correct types
        item_price = float(item_price)
        item_qty = int(item_qty)
        item_co2 = float(item_co2)

        cart = get_cart()
        # Find existing item
        for item in cart:
            if item['name'] == item_name:
                item['qty'] += item_qty
                break
        else:
            # If not found, create a new item
            new_item = {
                "id": len(cart) + 1,
                "name": item_name,
                "price": item_price,
                "qty": item_qty,
                "img": item_img,
                "co2_saved": item_co2,
            }
            cart.append(new_item)

        # Save the updated cart
        save_cart(cart)

        # Compute new cart count
        new_cart_count = sum(i['qty'] for i in cart)

        # Return JSON
        return jsonify({
            "success": True,
            "cart_count": new_cart_count
        })

    except Exception as e:
        print("Error in add_item_ajax:", e)
        return jsonify({"error": str(e)}), 500


@cart_bp.route("/add_voucher", methods=["POST"])
def add_voucher():
    voucher_code = request.form.get("voucher_code", "").strip()
    if voucher_code:
        session["voucher"] = voucher_code
        flash(f"Voucher '{voucher_code}' applied!", "success")
    return redirect(url_for("cart.shopping_cart"))

@cart_bp.route("/remove_voucher", methods=["POST"])
def remove_voucher():
    if "voucher" in session:
        del session["voucher"]
        flash("Voucher removed.", "info")
    return redirect(url_for("cart.shopping_cart"))

@cart_bp.route("/increase/<int:item_id>", methods=["POST"])
def increase_item(item_id):
    cart = get_cart()
    for item in cart:
        if item["id"] == item_id:
            item["qty"] += 1
            break
    save_cart(cart)
    flash("Item quantity increased!", "success")
    return redirect(url_for("cart.shopping_cart"))

@cart_bp.route("/decrease/<int:item_id>", methods=["POST"])
def decrease_item(item_id):
    cart = get_cart()
    for item in cart:
        if item["id"] == item_id and item["qty"] > 1:
            item["qty"] -= 1
            break
    save_cart(cart)
    flash("Item quantity decreased!", "success")
    return redirect(url_for("cart.shopping_cart"))

@cart_bp.route("/remove/<int:item_id>", methods=["POST"])
def remove_item(item_id):
    cart = get_cart()
    cart = [item for item in cart if item["id"] != item_id]
    save_cart(cart)
    flash("Item removed from cart!", "success")
    return redirect(url_for("cart.shopping_cart"))

@cart_bp.route("/empty", methods=["POST"])
def empty_cart():
    save_cart([])
    flash("Cart emptied successfully!", "success")
    return redirect(url_for("cart.shopping_cart"))

# -------------------------------------------------------------------------
# DELIVERY DETAILS
# -------------------------------------------------------------------------
@cart_bp.route("/delivery-details", methods=["GET", "POST"])
def delivery_details():
    cart = get_cart()
    if not cart:
        flash("Your cart is empty.", "warning")
        return redirect(url_for('cart.shopping_cart'))

    total_price = sum(item["price"] * item["qty"] for item in cart)
    total_items = sum(item["qty"] for item in cart)
    base_delivery_fee = 0 if total_price >= 60 else 5
    final_delivery_fee = base_delivery_fee
    service_fee = 3.99

    discount = 0
    voucher = session.get("voucher")
    if voucher:
        if voucher == "VOUCHER10":
            discount = 10
        elif voucher == "VOUCHER2":
            discount = 2

    final_total = total_price - discount + final_delivery_fee + service_fee
    points_received = sum(int(item.get("co2_saved", 0) * 100 * item["qty"]) for item in cart)
    current_date = date.today()
    tomorrow_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

    errors = {}

    if request.method == "POST":
        # --------------------------------------
        # 1) ALWAYS STORE FORM INPUT IN SESSION
        # --------------------------------------
        session['delivery_data'] = {
            'postalCode':       request.form.get('postalCode', "").strip(),
            'buildingName':     request.form.get('buildingName', "").strip(),
            'address':          request.form.get('address', "").strip(),
            'floorNumber':      request.form.get('floorNumber', "").strip(),
            'unitNumber':       request.form.get('unitNumber', "").strip(),
            'recipientName':    request.form.get('recipientName', "").strip(),
            'phoneNumber':      request.form.get('phoneNumber', "").strip(),
            'deliveryDate':     request.form.get('deliveryDate', "").strip(),
            'deliveryTimeSlot': request.form.get('deliveryTimeSlot', "").strip()
        }

        # Check the action (back or proceed)
        action = request.form.get('action')
        if action == "back":
            # User wants to go back to cart; we’ve already stored data in session
            return redirect(url_for('cart.shopping_cart'))

        # If not going "back", then proceed with validation, etc.
        # ------------------------------------
        # 2) VALIDATE AND PROCESS THE DELIVERY
        # ------------------------------------
        # (The rest of your validation code stays the same.)
        # ...
        if not session['delivery_data']['postalCode']:
            errors['postalCode'] = "Postal code is required."
        else:
            pc_val = session['delivery_data']['postalCode']
            if not re.match(r'^\d{6}$', pc_val):
                errors['postalCode'] = "Postal code must be 6 digits."

        if not session['delivery_data']['address']:
            errors['address'] = "Address is required."

        if not session['delivery_data']['recipientName']:
            errors['recipientName'] = "Recipient name is required."
        else:
            name_val = session['delivery_data']['recipientName']
            if not re.search(r'[A-Za-z]', name_val):
                errors['recipientName'] = "Please enter a valid name."

        phone_val = session['delivery_data']['phoneNumber']
        if not phone_val:
            errors['phoneNumber'] = "Phone number is required."
        else:
            phone_pattern = r'^\+?\d{8,15}$'
            if not re.match(phone_pattern, phone_val):
                errors['phoneNumber'] = "Please enter a valid phone number (8-15 digits)."

        date_str = session['delivery_data']['deliveryDate']
        slot_str = session['delivery_data']['deliveryTimeSlot']
        if not date_str:
            errors['deliveryDate'] = "Preferred delivery date is required."
        if not slot_str:
            errors['deliveryTimeSlot'] = "Please pick a 2-hour slot."

        # ... Additional time-slot checks ...
        # ...
        if errors:
            flash("Please fix the errors below before proceeding.", "danger")
            return render_template(
                "delivery_details.html",
                cart=cart,
                total_price=total_price,
                total_items=total_items,
                delivery_fee=final_delivery_fee,
                service_fee=service_fee,
                final_total=final_total,
                points_received=points_received,
                discount=discount,
                delivery_data=session['delivery_data'],  # pass back
                errors=errors,
                current_date=current_date,
                tomorrow_str=tomorrow_str
            )
        else:
            # If all good, store fees in session for next step
            session['final_delivery_fee'] = final_delivery_fee
            session['final_total'] = final_total

            # Store in CSV
            store_delivery_in_csv(session['delivery_data'])

            return redirect(url_for('cart.create_checkout_session'))

    # GET request or initial load
    delivery_data = session.get('delivery_data', {})
    return render_template(
        "delivery_details.html",
        cart=cart,
        total_price=total_price,
        total_items=total_items,
        delivery_fee=final_delivery_fee,
        service_fee=service_fee,
        final_total=final_total,
        points_received=points_received,
        discount=discount,
        delivery_data=delivery_data,
        errors=errors,
        current_date=current_date,
        tomorrow_str=tomorrow_str
    )

# -------------------------------------------------------------------------
# STRIPE CHECKOUT
# -------------------------------------------------------------------------
app.config['STRIPE_PUBLIC_KEY'] = 'pk_test_51QTSLzCyJbY5AAxEudYBToGOui7aFXfkmqzzhWzH99EGDBOH2WSEbmSianjUY03qVJTBYJoweOUOTLZcYSrT8HLV00w6h6890j'
app.config['STRIPE_SECRET_KEY'] = 'sk_test_51QTSLzCyJbY5AAxE6dOmuLulPFJftHRdiOWNojThkNRuym8eLfDCmSYyfFNz8CyGyzcPToftHXuStZFvU7Er4gtI00089HpIjx'
stripe.api_key = app.config['STRIPE_SECRET_KEY']

@cart_bp.route('/create-checkout-session', methods=['POST', 'GET'])
def create_checkout_session():
    """
    Creates a Stripe Checkout session.
    """
    try:
        cart = get_cart()
        if not cart:
            flash("Your cart is empty.", "warning")
            return redirect(url_for('cart.shopping_cart'))

        final_delivery_fee = session.get('final_delivery_fee', 0)
        service_fee = 3.99

        # Build line items for Stripe
        line_items = []
        for item in cart:
            line_items.append({
                'price_data': {
                    'currency': 'sgd',
                    'product_data': {
                        'name': item['name'],
                    },
                    'unit_amount': int(item['price'] * 100),
                },
                'quantity': item['qty'],
            })

        # Add Delivery Fee if applicable
        if final_delivery_fee > 0:
            line_items.append({
                'price_data': {
                    'currency': 'sgd',
                    'product_data': {
                        'name': 'Delivery Fee',
                    },
                    'unit_amount': int(final_delivery_fee * 100),
                },
                'quantity': 1,
            })

        # Add Service Fee
        line_items.append({
            'price_data': {
                'currency': 'sgd',
                'product_data': {
                    'name': 'Service Fee',
                },
                'unit_amount': int(service_fee * 100),
            },
            'quantity': 1,
        })

        # Voucher discount logic:
        coupon_discount = None
        voucher = session.get("voucher")
        if voucher:
            if voucher == "VOUCHER10":
                coupon_discount = "coupon_10"   # This coupon must exist in Stripe
            elif voucher == "VOUCHER2":
                coupon_discount = "coupon_2"    # This coupon must exist in Stripe

        # Pass the discount to Stripe if a valid coupon is found
        discounts = [{'coupon': coupon_discount}] if coupon_discount else None
        customer_email = session.get("customer_email")

        session_stripe = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=line_items,
            mode='payment',
            discounts=discounts,  # Now enabled and passed to Stripe
            customer_email=customer_email,
            success_url=url_for('cart.thank_you', _external=True) + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=url_for('cart.shopping_cart', _external=True),
        )

        return redirect(session_stripe.url, code=303)

    except Exception as e:
        flash("Error creating Stripe session: " + str(e), "danger")
        return redirect(url_for('cart.shopping_cart'))

@cart_bp.route("/thank_you")
def thank_you():
    """
    Final confirmation page after Stripe payment success.
    """
    session_id = request.args.get('session_id')
    if session_id:
        session_stripe = stripe.checkout.Session.retrieve(session_id)
    else:
        session_stripe = None

    cart = get_cart()  # Get items from the session
    delivery_data = session.get("delivery_data", {})
    order_id = random.randint(100000, 999999)

    # Build shipping address from session data.
    postal_code   = delivery_data.get("postalCode", "")
    address       = delivery_data.get("address", "")
    building_name = delivery_data.get("buildingName", "")
    floor_number  = delivery_data.get("floorNumber", "")
    unit_number   = delivery_data.get("unitNumber", "")
    recipientName = delivery_data.get("recipientName", "Valued Customer")
    shipping_address = f"{address}, {building_name} #{floor_number}-{unit_number}, Singapore {postal_code}"

    shipping_method = "FairPrice Eco Electric Van"
    payment_method  = "VISA Debit Card 4242"  # Example payment method

    total_price = sum(item["price"] * item["qty"] for item in cart)
    discount = 0
    voucher = session.get("voucher")
    if voucher:
        if voucher == "VOUCHER10":
            discount = 10
        elif voucher == "VOUCHER2":
            discount = 2

    final_delivery_fee = session.get("final_delivery_fee", 0)
    service_fee = 3.99
    final_total = total_price - discount + final_delivery_fee + service_fee

    # Delivery ETA calculation (existing logic)...
    deliveryDateStr = delivery_data.get("deliveryDate", "")
    deliverySlot    = delivery_data.get("deliveryTimeSlot", "")
    delivery_eta_text = "Your order will be delivered soon!"
    try:
        now = datetime.now()
        year  = int(deliveryDateStr[0:4])
        month = int(deliveryDateStr[5:7])
        day   = int(deliveryDateStr[8:10])
        slotParts = deliverySlot.split("-")
        start_hour = int(slotParts[0]) if len(slotParts) > 0 else 8
        chosen_dt = datetime(year, month, day, start_hour, 0)
        diff = chosen_dt - now
        hours = diff.total_seconds() / 3600.0
        if hours < 0:
            delivery_eta_text = "Your selected delivery time is in the past. Please contact us!"
        else:
            if hours < 24:
                delivery_eta_text = f"Your order will be delivered in about {int(hours)} hour(s)."
            else:
                days = int(hours // 24)
                remainder_hours = int(hours % 24)
                if days == 1:
                    delivery_eta_text = f"Your order will be delivered in about 1 day"
                    if remainder_hours:
                        delivery_eta_text += f" {remainder_hours} hour(s)."
                    else:
                        delivery_eta_text += "."
                else:
                    delivery_eta_text = f"Your order will be delivered in about {days} days"
                    if remainder_hours:
                        delivery_eta_text += f" {remainder_hours} hour(s)."
                    else:
                        delivery_eta_text += "."
    except Exception as e:
        print("Error calculating delivery ETA:", e)

    # Calculate points earned from this order.
    points_earned = sum(
        int(item.get("co2_saved", 0) * 100 * item["qty"]) for item in cart
    )
    print("Points earned from this order:", points_earned)

    # Retrieve existing points from session and update them.
    existing_points = session.get('user_points', 0)
    updated_points = existing_points + points_earned
    session['user_points'] = updated_points
    print("Updated user_points in session:", session['user_points'])

    # Clear the cart now that purchase is complete.
    save_cart([])

    return render_template(
        "thank_you.html",
        session=session_stripe,
        order_id=order_id,
        user_name=recipientName,
        shipping_address=shipping_address,
        payment_method=payment_method,
        shipping_method=shipping_method,
        postal_code=postal_code,
        cart=cart,
        total_price=total_price,
        discount=discount,
        final_delivery_fee=final_delivery_fee,
        service_fee=service_fee,
        final_total=final_total,
        delivery_eta_text=delivery_eta_text
    )

@cart_bp.route("/cancel")
def cancel():
    flash("Checkout was cancelled.", "warning")
    return redirect(url_for("cart.shopping_cart"))

# Register Blueprint
app.register_blueprint(cart_bp, url_prefix='/cart')

# -------------------------------------------------------------------------
# MAIN ENTRY POINT
# -------------------------------------------------------------------------

