from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from create_user_db import db, User

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SECRET_KEY'] = 'FairpriceEco'
db.init_app(app)


@app.before_first_request
def clear_session():
    session.clear()


# Create database tables
with app.app_context():
    db.create_all()


# Home route
@app.route('/')
def home():
    # Check if the user is logged in
    if 'user' not in session:
        return redirect(url_for('login'))

    # Pass the user data to the template
    user = User.query.filter_by(email=session['user']).first()
    return render_template('home.html', user=user)


# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email).first()
        if user and user.password == password:  # Replace with password hashing if used
            session['user'] = user.email  # Store user email in session
            print(f"Login successful. User '{user.email}' logged in.")
            return redirect(url_for('home'))
        print("Invalid login attempt.")
        return render_template('login.html', error="Invalid credentials")

    return render_template('login.html')


# Logout route
@app.route('/logout')
def logout():
    # Clear the user session
    session.clear()
    return redirect(url_for('login'))


# Signup route
@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method == "POST":
        username = request.form.get("username")
        email = request.form.get("email")
        password = request.form.get("password")

        if not username or not email or not password:
            return jsonify({"status": "error", "message": "All fields are required!"})

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return jsonify({"status": "error", "message": "Email already registered!"})

        try:
            new_user = User(username=username, email=email, password=password)
            db.session.add(new_user)
            db.session.commit()
            return jsonify({"status": "success", "message": "Account created successfully!"})
        except Exception as e:
            db.session.rollback()
            return jsonify({"status": "error", "message": "An error occurred. Please try again later."})

    return render_template("signup.html")  # Render signup form for GET requests


# Mock Google Login Route
@app.route('/auth/google')
def auth_google():
    # Redirect to a mock Google login page
    return render_template('google_login.html')


# Mock Google Login Callback
@app.route('/auth/google/callback', methods=['POST'])
def google_callback():
    # Extract the user's "email" from the form submission (simulating a real callback)
    email = request.form.get('email')

    if not email:
        return jsonify({"status": "error", "message": "Email is required!"})

    # Check if the user exists in the database
    user = User.query.filter_by(email=email).first()
    if user:
        session['user'] = user.email
        print(f"Google login successful. User '{user.email}' logged in.")
        return redirect(url_for('home'))
    else:
        # If user doesn't exist, create a new user
        try:
            new_user = User(username=email.split('@')[0], email=email, password="google_auth")  # Placeholder password
            db.session.add(new_user)
            db.session.commit()
            session['user'] = new_user.email
            return redirect(url_for('home'))
        except Exception as e:
            db.session.rollback()
            return jsonify({"status": "error", "message": f"An error occurred: {e}"})

    return jsonify({"status": "success", "message": "Google login successful!"})


# Update route
@app.route('/update_user/<int:user_id>', methods=['GET', 'POST'])
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    if request.method == 'POST':
        user.username = request.form.get('username')
        user.email = request.form.get('email')
        user.password = request.form.get('password')
        db.session.commit()
        return jsonify({"status": "success", "message": "User updated successfully!"})
    return render_template('update.html', user=user)


@app.route('/account', methods=['GET', 'POST'])
def account():
    if 'user' not in session:
        return redirect(url_for('login'))  # Redirect if user is not logged in

    user = User.query.filter_by(email=session['user']).first()

    if request.method == 'POST':
        # Update user information
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')

        if not username or not email or not password:
            return jsonify({"status": "error", "message": "All fields are required!"})

        try:
            user.username = username
            user.email = email
            user.password = password
            db.session.commit()
            return jsonify({"status": "success", "message": "Account updated successfully!"})
        except Exception as e:
            db.session.rollback()
            return jsonify({"status": "error", "message": f"An error occurred: {e}"})

    return render_template('account.html', user=user)


# Delete route
@app.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    try:
        db.session.delete(user)
        db.session.commit()
        session.clear()  # Clear session after user deletion
        return jsonify({"status": "success", "message": "Account deleted successfully!"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": f"An error occurred: {e}"})


if __name__ == '__main__':
    app.run(debug=True)
