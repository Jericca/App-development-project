from flask import Flask, request, render_template, redirect, url_for, flash, jsonify
import shelve
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # For flashing messages


# Helper function to validate expiry date
def is_valid_expiry_date(expiry_date):
    try:
        expiry_datetime = datetime.strptime(expiry_date, "%Y-%m-%d")
        return expiry_datetime.date() >= datetime.now().date()  # ✅ Compare as date objects
    except ValueError:
        return False


staff_credentials = {
    "ab1234": "password1.",
    "ac5678": "secure",
    "ad9012": "admin@123",
}


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/login', methods=['POST'])
def stafflogin():
    staffID = request.form.get('staffID')
    password = request.form.get("password")

    if staffID in staff_credentials and staff_credentials[staffID] == password:
        return redirect(url_for("home_after_login"))
    else:
        flash("Invalid Staff ID or Password. Please try again.")
        return redirect(url_for("home"))


@app.route('/check_voucher_id')
def check_voucher_id():
    """Check if the given voucher ID already exists in the database."""
    voucher_id = request.args.get("voucher_id", "").strip()
    with shelve.open("vouchers.db") as db:
        exists = voucher_id in db
    return jsonify({"exists": exists})


@app.route('/api/vouchers', methods=['GET'])
def get_vouchers():
    """API endpoint to retrieve the latest vouchers from vouchers.db"""
    with shelve.open("vouchers.db") as db:
        vouchers = dict(db)
    return jsonify(vouchers)


@app.route('/create_voucher', methods=['GET', 'POST'])
def create_voucher():
    if request.method == 'POST':
        voucher_id = request.form['voucher_id'].strip()
        voucher_name = request.form['voucher_name'].strip()
        points_needed = request.form['points_needed'].strip()
        expiry_date = request.form['expiry_date'].strip()
        expiry_time = "23:59"  # ✅ Default expiry time

        try:
            points_needed = int(points_needed)
            if points_needed < 1000:
                flash('Points needed must be at least 1000.')
                return redirect(url_for('create_voucher'))
        except ValueError:
            flash('Invalid points value. Please enter a number.')
            return redirect(url_for('create_voucher'))

        if not is_valid_expiry_date(expiry_date):
            flash('Invalid expiry date. Must be today or a future date.')
            return redirect(url_for('create_voucher'))

        with shelve.open('vouchers.db', writeback=True) as db:
            if voucher_id in db:
                flash('Voucher ID already exists. Please use a different ID.')
                return redirect(url_for('create_voucher'))
            else:
                db[voucher_id] = {
                    'voucher_name': voucher_name,
                    'points_needed': points_needed,
                    'expiry_date': expiry_date,
                    'expiry_time': expiry_time  # ✅ Stored default expiry time
                }
                flash('Voucher created successfully.')

        return redirect(url_for('view_vouchers'))

    return render_template('create_voucher.html')


@app.route('/view_vouchers', methods=['GET'])
def view_vouchers():
    expired_vouchers = []

    with shelve.open('vouchers.db', writeback=True) as db:
        vouchers = dict(db)
        today = datetime.now().date()  # ✅ Convert today to date

        # ✅ Remove expired vouchers
        for voucher_id, voucher in list(vouchers.items()):
            expiry_date = datetime.strptime(voucher['expiry_date'], "%Y-%m-%d").date()  # ✅ Convert expiry date to date
            if expiry_date < today:  # ✅ Compare date to date (fixed issue)
                expired_vouchers.append(voucher_id)
                del db[voucher_id]  # Delete expired voucher

        if expired_vouchers:
            flash(f"Removed {len(expired_vouchers)} expired voucher(s).")

    return render_template('view_vouchers.html', vouchers=vouchers)


@app.route('/delete_voucher/<voucher_id>', methods=['POST'])
def delete_voucher(voucher_id):
    with shelve.open('vouchers.db', writeback=True) as db:
        if voucher_id in db:
            del db[voucher_id]
            flash('Voucher deleted successfully.')
        else:
            flash('Voucher ID not found.')
    return redirect(url_for('view_vouchers'))


@app.route('/update_voucher/<voucher_id>', methods=['GET', 'POST'])
def update_voucher(voucher_id):
    with shelve.open('vouchers.db', writeback=True) as db:
        if voucher_id not in db:
            flash('Voucher ID not found.')
            return redirect(url_for('view_vouchers'))

        voucher = db[voucher_id]

        if request.method == 'POST':
            points_needed = request.form['points_needed'].strip()
            expiry_date = request.form['expiry_date'].strip()
            expiry_time = "23:59"  # ✅ Default expiry time for updates

            try:
                points_needed = int(points_needed)
                if points_needed < 1000:
                    flash('Points needed must be at least 1000.')
                    return redirect(url_for('update_voucher', voucher_id=voucher_id))
            except ValueError:
                flash('Invalid points value. Please enter a number.')
                return redirect(url_for('update_voucher', voucher_id=voucher_id))

            if not is_valid_expiry_date(expiry_date):
                flash('Invalid expiry date. Must be today or a future date.')
                return redirect(url_for('update_voucher', voucher_id=voucher_id))

            # ✅ Update voucher details with default expiry time
            voucher['points_needed'] = points_needed
            voucher['expiry_date'] = expiry_date
            voucher['expiry_time'] = expiry_time
            db[voucher_id] = voucher

            flash('Voucher updated successfully.')
            return redirect(url_for('view_vouchers'))

        return render_template('update_voucher.html', voucher=voucher, voucher_id=voucher_id)


if __name__ == '__main__':
    app.run(debug=True, port=5001)  # Run the staff backend on port 5001



