from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Setup the SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///products.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Product Model:
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200), nullable=True)

    def __repr__(self):
        return f"Product('{self.name}', '{self.price}')"

if __name__ == '__main__':
    with app.app_context():
        db.drop_all()  # Drops all tables
        db.create_all()  # Creates all tables

def create_tables():
    try:
        # Create the tables before running the app
        db.create_all()
        print("Database tables created successfully.")
    except Exception as e:
        print(f"Error creating database tables: {e}")

# Home page - Display all products
@app.route('/')
def index():
    try:
        products = Product.query.all()
        return render_template('index.html', products=products)
    except Exception as e:
        return f"Error fetching products: {e}"

# Add Product
@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        try:
            name = request.form['name']
            price = request.form['price']
            description = request.form['description']

            # Check if name and price are valid
            if not name or not price:
                return "Name and price are required", 400
            try:
                price = float(price)
            except ValueError:
                return "Price must be a number", 400

            new_product = Product(name=name, price=price, description=description)
            db.session.add(new_product)
            db.session.commit()
            return redirect(url_for('index'))
        except Exception as e:
            return f"Error adding product: {e}", 500
    return render_template('add_product.html')

# Update Product
@app.route('/update_product/<int:id>', methods=['GET', 'POST'])
def update_product(id):
    try:
        product = Product.query.get(id)
        if not product:
            return "Product not found", 404

        if request.method == 'POST':
            try:
                product.name = request.form['name']
                product.price = float(request.form['price'])
                product.description = request.form['description']
                db.session.commit()
                return redirect(url_for('index'))
            except ValueError:
                return "Price must be a number", 400
            except Exception as e:
                return f"Error updating product: {e}", 500

        return render_template('update_product.html', product=product)
    except Exception as e:
        return f"Error fetching product for update: {e}", 500

# Delete Product
@app.route('/delete_product/<int:id>')
def delete_product(id):
    try:
        product = Product.query.get(id)
        db.session.delete(product)
        db.session.commit()
        return redirect(url_for('index'))
    except Exception as e:
        return f"Error deleting product: {e}", 500

# Cart Management
@app.route('/add_to_cart/<int:id>')
def add_to_cart(id):
    try:
        product = Product.query.get(id)
        if not product:
            return "Product not found", 404

        if 'cart' not in session:
            session['cart'] = []

        session['cart'].append(product.id)
        session.modified = True
        return redirect(url_for('index'))
    except Exception as e:
        return f"Error adding to cart: {e}", 500

@app.route('/cart')
def cart():
    try:
        cart_products = Product.query.filter(Product.id.in_(session.get('cart', []))).all()
        return render_template('cart.html', products=cart_products)
    except Exception as e:
        return f"Error fetching cart products: {e}", 500

@app.route('/clear_cart')
def clear_cart():
    try:
        session.pop('cart', None)
        return redirect(url_for('cart'))
    except Exception as e:
        return f"Error clearing cart: {e}", 500



if __name__ == '__main__':
    app.run(debug=True, port=5001)