from flask import Flask, render_template, request, redirect, url_for, session, flash
import requests
import os

app = Flask(__name__, template_folder="pages1")
app.secret_key = 'your_secret_key'

# API Base URL (Ensure this matches where `app.py` is running)
API_BASE_URL = "http://127.0.0.1:5001/api"

@app.route('/')
def home():
    """ Fetch all products from the API and render home page """
    try:
        response = requests.get(f"{API_BASE_URL}/products")
        if response.status_code != 200:
            return f"Error fetching products: {response.text}", 500

        products = response.json()
        return render_template("main_page.html", products=products)
    except Exception as e:
        return f"Error connecting to API: {e}", 500

@app.route("/category/<category_name>")
def category_page(category_name):
    """ Fetch products by category """
    try:
        response = requests.get(f"{API_BASE_URL}/products")
        if response.status_code != 200:
            return f"Error fetching products: {response.text}", 500

        all_products = response.json()
        products = [p for p in all_products if category_name.lower() in (p.get("tags") or "").lower()]
        return render_template('category_user.html', category_name=category_name, products=products)
    except Exception as e:
        return f"Error fetching products: {e}", 500


@app.route('/add_to_cart/<int:id>')
def add_to_cart(id):
    """ Add products to cart """
    try:
        print(f"Fetching Product ID: {id}")  # Debugging line
        response = requests.get(f"{API_BASE_URL}/product/{id}")

        if response.status_code != 200:
            print(f"Product {id} not found!")  # Debugging line
            return "Product not found", 404

        product = response.json()
        print(f"Product Data: {product}")  # Debugging line

        if 'carts' not in session:
            session['carts'] = {}

        product_id = str(id)
        session['carts'][product_id] = session['carts'].get(product_id, 0) + 1
        session.modified = True  # Ensure session updates

        print(f"Cart: {session['carts']}")  # Debugging line

        return redirect(request.referrer or url_for('home'))
    except Exception as e:
        print(f"Error adding to cart: {e}")  # Debugging line
        return f"Error adding to cart: {e}", 500


@app.route('/cart')
def cart():
    """ View cart products """
    try:
        cart_items = session.get('carts', {})
        if not cart_items:
            return render_template('carts.html', products=[])

        products = []
        for product_id in cart_items.keys():
            response = requests.get(f"{API_BASE_URL}/product/{product_id}")
            if response.status_code == 200:
                product = response.json()
                product["quantity_in_cart"] = cart_items[product_id]
                products.append(product)

        return render_template('carts.html', products=products)
    except Exception as e:
        return f"Error fetching cart products: {e}", 500

@app.route('/clear_cart')
def clear_cart():
    """ Clear the cart """
    try:
        session.pop('carts', None)
        return redirect(url_for('cart'))
    except Exception as e:
        return f"Error clearing cart: {e}", 500

@app.route('/update_cart/<int:id>/<string:action>')
def update_cart(id, action):
    """ Increase or decrease item quantity in cart """
    try:
        if 'carts' in session and str(id) in session['carts']:
            if action == 'increase':
                session['carts'][str(id)] += 1
            elif action == 'decrease':
                session['carts'][str(id)] -= 1
                if session['carts'][str(id)] <= 0:
                    del session['carts'][str(id)]

        session.modified = True
        return redirect(url_for('cart'))
    except Exception as e:
        return f"Error updating cart: {e}", 500

@app.route('/delete_product/<int:id>')
def delete_product(id):
    """ Remove a product from cart """
    try:
        if 'carts' in session and str(id) in session['carts']:
            del session['carts'][str(id)]
            session.modified = True
        return redirect(url_for('cart'))
    except Exception as e:
        return f"Error deleting product from cart: {e}", 500

if __name__ == "__main__":
    app.run(debug=True, port=5002)  # Running on a different port
