from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_migrate import Migrate
import os
from werkzeug.utils import secure_filename
import re
from database import db


app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Setup the SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///products.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
migrate = Migrate(app, db)
tag = ["Best Seller", "Promotion", "Recommended"]
app.config['UPLOAD_FOLDER'] = 'static/uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


# Product Model:
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200), nullable=True)
    tags = db.Column(db.String(200), nullable=True)
    image = db.Column(db.String(200), nullable=True)
    co2_saved = db.Column(db.Float, nullable=True)
    quantity = db.Column(db.Float, nullable=True)

    def __repr__(self):
        return f"Product('{self.name}', '{self.price}')"


# 📌 ✅ API: Get all products
@app.route('/api/products', methods=['GET'])
def get_products():
    products = Product.query.all()
    product_list = [{
        "id": p.id,
        "name": p.name,
        "price": p.price,
        "description": p.description,
        "tags": p.tags,
        "image": p.image,
        "co2_saved": p.co2_saved,
        "quantity": p.quantity
    } for p in products]
    return jsonify(product_list)


# 📌 ✅ API: Get a single product by ID
@app.route('/api/product/<int:id>', methods=['GET'])
def get_product(id):
    product = Product.query.get(id)
    if not product:
        return jsonify({"error": "Product not found"}), 404

    product_data = {
        "id": product.id,
        "name": product.name,
        "price": product.price,
        "description": product.description,
        "tags": product.tags,
        "image": product.image,
        "co2_saved": product.co2_saved,
        "quantity": product.quantity
    }
    return jsonify(product_data)


# 📌 ✅ API: Add a product via API
@app.route('/api/add_product', methods=['POST'])
def api_add_product():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400

        name = data.get("name", "").strip()
        price = data.get("price")
        description = data.get("description", "").strip()
        tags = ", ".join(data.get("tags", []))
        image = data.get("image", "")
        co2_saved = data.get("co2_saved", 0)
        quantity = data.get("quantity", 0)

        if not name or price is None or co2_saved is None:
            return jsonify({"error": "Missing required fields"}), 400

        if Product.query.filter_by(name=name).first():
            return jsonify({"error": "Product with this name already exists"}), 400

        new_product = Product(name=name, price=float(price), description=description, tags=tags,
                              image=image, co2_saved=float(co2_saved), quantity=float(quantity))

        db.session.add(new_product)
        db.session.commit()

        print(f"✅ Product {name} added successfully!")  # Debugging Line

        return jsonify({"message": "Product added successfully!"}), 201

    except Exception as e:
        print(f"❌ Error adding product: {str(e)}")  # Debugging Line
        return jsonify({"error": str(e)}), 500


# 📌 ✅ API: Update a product via API
@app.route('/api/update_product/<int:id>', methods=['PUT'])
def api_update_product(id):
    try:
        product = Product.query.get(id)
        if not product:
            return jsonify({"error": "Product not found"}), 404

        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400

        product.name = data.get("name", product.name).strip()
        product.price = float(data.get("price", product.price))
        product.description = data.get("description", product.description).strip()
        product.tags = ", ".join(data.get("tags", product.tags.split(", ")))
        product.image = data.get("image", product.image)
        product.co2_saved = float(data.get("co2_saved", product.co2_saved))
        product.quantity = float(data.get("quantity", product.quantity))

        db.session.commit()
        return jsonify({"message": "Product updated successfully!"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# 📌 ✅ API: Delete a product via API
@app.route('/api/delete_product/<int:id>', methods=['DELETE'])
def api_delete_product(id):
    try:
        product = Product.query.get(id)
        if not product:
            return jsonify({"error": "Product not found"}), 404

        db.session.delete(product)
        db.session.commit()
        return jsonify({"message": "Product deleted successfully!"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# 🛠️ 🔹 Keep your existing web routes untouched 🔹 🛠️
with app.app_context():
    db.create_all()
    print("Database tables created successfully!")

if __name__ == '__main__':
    app.run(debug=True, port=5001)  # Running on port 5001
