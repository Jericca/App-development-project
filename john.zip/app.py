import shelve
from flask import Flask, render_template, request, jsonify, redirect, url_for
# Chatbot import
from transformers import AutoModelForCausalLM, AutoTokenizer
from sentence_transformers import SentenceTransformer, util
import torch
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import gspread
from oauth2client.service_account import ServiceAccountCredentials


# Initialize Flask app
app = Flask(__name__)
FAQ_DB = "faq_data.db"

# Route for FAQ Management
@app.route('/', methods=['GET', 'POST'])
def faq():
    if request.method == 'POST':
        # Get form data
        faq_id = request.form.get('faq_id')  # Hidden input for editing
        question = request.form.get('question')
        answer = request.form.get('answer')

        # Save or update the FAQ
        with shelve.open(FAQ_DB) as db:
            if faq_id:  # If faq_id exists, update the FAQ
                db[faq_id] = {"question": question, "answer": answer}
            else:  # Otherwise, add a new FAQ
                new_id = str(len(db) + 1)
                db[new_id] = {"question": question, "answer": answer}

        return redirect(url_for('faq'))

    # Retrieve all FAQs
    with shelve.open(FAQ_DB) as db:
        faqs = dict(db)

    return render_template('faq.html', faqs=faqs)

# Route for Deleting an FAQ
@app.route('/delete/<faq_id>', methods=['POST'])
def delete_faq(faq_id):
    with shelve.open(FAQ_DB) as db:
        if faq_id in db:
            del db[faq_id]
    return redirect(url_for('faq'))


# File Upload Route
@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    # Save the file to the server (e.g., a uploads/ directory)
    file.save(f'uploads/{file.filename}')
    return jsonify({'message': 'File uploaded successfully', 'filename': file.filename})


# Load OpenAI GPT-2 model from Hugging Face
MODEL_NAME = "gpt2-large"  # Use 'gpt2-medium' or 'gpt2-large' for better responses
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, device_map="auto")
similarity_model = SentenceTransformer("all-MiniLM-L6-v2")

# Ensure tokenizer has a padding token (GPT-2 doesn't have one by default)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token  # Use EOS token as PAD


# Define assistant behavior
FALLBACK_PROMPT = (
    "Your name is Melvin, and you are a helpful assistant for an eco-friendly grocery store. "
    "You only answer questions about eco-friendly products, groceries, or sustainable practices. "
    "For any other topic, politely inform the user that you are unable to help and suggest contacting support."
)

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        user_message = request.json.get('message', '').strip().lower()
        if not user_message:
            return jsonify({"reply": "Please enter a valid question."})

        # Custom responses for greetings
        greetings = ["hi", "hello", "hey", "good morning", "good afternoon", "good evening",
                    "howdy", "greetings", "what's up", "sup", "yo", "hiya", "hi there", "hello there",
                    "hey there", "how's it going", "how are you", "how is it going", "how do you do",
                    "nice to meet you", "pleased to meet you", "good to see you", "good to meet you",
                    "what is your name?", "who are you?", "what can you do?", "what do you do?"]
        if any(greet in user_message for greet in greetings):
            return jsonify({"reply": "Hello! My name is Melvin, NTUC FairPrice Eco's AI Assistant. How can I assist you with your eco-friendly grocery needs today?"})

        with shelve.open(FAQ_DB) as db:
            faq_data = {k: v for k, v in db.items()}

        questions = [faq["question"] for faq in faq_data.values()]
        answers = [faq["answer"] for faq in faq_data.values()]
        question_embeddings = similarity_model.encode(questions, convert_to_tensor=True)
        user_embedding = similarity_model.encode(user_message, convert_to_tensor=True)

        similarity_scores = util.pytorch_cos_sim(user_embedding, question_embeddings)[0]
        best_match_index = torch.argmax(similarity_scores).item()
        best_score = similarity_scores[best_match_index].item()

        if best_score > 0.85:  # Increased threshold for confidence
            return jsonify({"reply": answers[best_match_index]})

        input_prompt = f"{FALLBACK_PROMPT}\nUser: {user_message}\nAssistant:"
        inputs = tokenizer(
            input_prompt,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=1024
        ).to("cuda" if torch.cuda.is_available() else "cpu")

        outputs = model.generate(
            **inputs,
            max_new_tokens=50,
            temperature=0.2,  # Reduced randomness
            top_k=30,  # Stricter token selection
            top_p=0.7,  # Further reduce less likely options
            repetition_penalty=2.5,  # Stronger penalty for repetition
            do_sample=True
        )
        bot_reply = tokenizer.decode(outputs[0], skip_special_tokens=True)

        if "Assistant:" in bot_reply:
            bot_reply = bot_reply.split("Assistant:")[-1].strip()
        bot_reply = bot_reply.split("\n")[0]

        eco_keywords = ["eco-friendly", "sustainable", "organic", "green", "recycle", "reuse"]
        if not any(keyword in bot_reply.lower() for keyword in eco_keywords):
            bot_reply = (
                "I can only assist with eco-friendly grocery-related inquiries. "
                "Please rephrase or ask about something in this category."
            )

        if not bot_reply.strip():
            bot_reply = "I'm here to assist with eco-friendly grocery questions. Could you ask something else?"

        return jsonify({"reply": bot_reply})

    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({"reply": "Sorry, there was an error processing your request. Please try again later."})

# Form Page
# Google Sheets API Setup
SCOPE = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
CREDS_FILE = "instance/sigma-rarity-310809-f594f473ab4f.json"  # Path to your JSON credentials
SPREADSHEET_NAME = "HelpRequests"  # Change this to your actual Google Sheet name

# Authenticate and connect to Google Sheets
creds = ServiceAccountCredentials.from_json_keyfile_name(CREDS_FILE, SCOPE)
client = gspread.authorize(creds)
sheet = client.open(SPREADSHEET_NAME).sheet1  # Select the first sheet

# Route to render the form
@app.route('/contact', methods=['GET'])
def contact_form():
    return render_template('form.html')

# Route to submit the form and save data to Google Sheets
@app.route('/submit', methods=['POST'])
def submit():
    print("🔥 Form submission received.")

    # Fetch existing data to determine next available ID
    data = sheet.get_all_values()
    next_id = int(data[-1][0]) + 1 if len(data) > 1 else 1  # Auto-increment ID

    issue_description = request.form.get('issueDescription', '')
    issue_details = request.form.get('issueDetails', '')
    name = request.form.get('name', '')
    email = request.form.get('email', '')
    image = request.files.get('uploadImages')

    # Ensure the image filename is stored properly
    image_filename = "No Image"  # Default value
    if image and image.filename:
        image_filename = image.filename
        image.save(f"static/uploads/{image_filename}")

    # Append the new row with all values
    row_data = [str(next_id), issue_description, issue_details, name, email, image_filename]
    print(f"📊 Debug: Row being added to Google Sheets: {row_data}")

    sheet.append_row(row_data)
    print(f"✅ New request added with ID {next_id}")

    return redirect(url_for('view_help_requests'))





# Help-Request Page

# Route to fetch help requests from Google Sheets
@app.route('/help-requests', methods=['GET'])
def view_help_requests():
    print("🔄 Fetching latest help requests from Google Sheets...")  # Debugging

    sheet = client.open(SPREADSHEET_NAME).sheet1
    data = sheet.get_all_values()

    headers = data[0] if data else []  # First row (column names)
    rows = data[1:] if len(data) > 1 else []  # Remaining rows (actual data)

    # Ensure the correct column order
    help_requests = [
        {
            "id": row[0] if len(row) > 0 else "",
            "issue_description": row[1] if len(row) > 1 else "",
            "issue_details": row[2] if len(row) > 2 else "",
            "name": row[3] if len(row) > 3 else "",
            "email": row[4] if len(row) > 4 else "",
            "image_filename": row[5] if len(row) > 5 else "No Image"  # Handle missing images
        }
        for row in rows
    ]

    print(f"✅ Loaded {len(help_requests)} help requests.")  # Debugging
    return render_template("help-requests.html", help_requests=help_requests)

# Route to delete a help request
@app.route('/delete-request/<request_id>', methods=['DELETE'])
def delete_request(request_id):
    print(f"🗑 Attempting to delete request with ID: {request_id}")  # Debugging log

    try:
        # Ensure request_id is actually a number
        if not request_id.isdigit():
            print(f"❌ Error: Request ID '{request_id}' is not a valid integer.")
            return jsonify({"error": "Invalid request ID format"}), 400

        request_id = int(request_id)  # Convert to integer safely

        # Fetch all rows from Google Sheets
        data = sheet.get_all_values()

        # Find the row index where the request ID matches
        row_index = None
        for index, row in enumerate(data[1:], start=2):  # Start from row 2 (skip headers)
            if row and row[0].isdigit() and int(row[0]) == request_id:  # Check ID
                row_index = index
                break

        if row_index:
            sheet.delete_rows(row_index)  # Delete the row from Google Sheets
            print(f"✅ Successfully deleted request ID {request_id}")
            return jsonify({"success": True, "message": "Request deleted successfully"}), 200
        else:
            print(f"⚠ Request ID {request_id} not found in Google Sheets.")
            return jsonify({"error": "Request ID not found"}), 404

    except Exception as e:
        print(f"❌ Error deleting request: {e}")
        return jsonify({"error": "Failed to delete request"}), 500



# Debug route to check Google Sheets data
@app.route('/debug-google-sheets')
def debug_google_sheets():
    data = sheet.get_all_values()
    return jsonify(data)


if __name__ == '__main__':
    app.run(debug=True, port=5000)