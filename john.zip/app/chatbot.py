def get_response(user_message):
    # Basic example logic
    responses = {
        "hello": "Hi there! How can I help you?",
        "how are you?": "I'm just a bot, but I'm doing great! How about you?",
        "what is your name?": "I'm your friendly chatbot assistant."
    }
    
    # Default response if no match is found
    return responses.get(user_message.lower(), "I'm sorry, I didn't understand that.")


